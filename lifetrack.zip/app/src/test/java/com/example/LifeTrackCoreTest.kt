package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.LifeTrackDatabase
import com.example.data.local.LifeTrackRepository
import com.example.data.local.UserPreferencesRepository
import com.example.service.StartTimerResult
import com.example.service.TimerManager
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class LifeTrackCoreTest {

    private lateinit var context: Context
    private lateinit var database: LifeTrackDatabase
    private lateinit var preferencesRepository: UserPreferencesRepository
    private lateinit var repository: LifeTrackRepository
    private lateinit var timerManager: TimerManager

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        database = Room.inMemoryDatabaseBuilder(context, LifeTrackDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        preferencesRepository = UserPreferencesRepository(context)
        repository = LifeTrackRepository(database, preferencesRepository)
        timerManager = TimerManager(context, repository)
    }

    @After
    fun teardown() {
        database.close()
    }

    @Test
    fun `default 12 activities are seeded cleanly and custom activities can be added`() = runTest {
        repository.ensureDefaultActivitiesSeeded()
        val activities = repository.activities.first()
        assertEquals(12, activities.size)
        val names = activities.map { it.name }
        assertTrue(names.containsAll(listOf(
            "Exercise", "Sleep", "Walking", "Swimming", "Sports", "Working",
            "Reading", "Studying", "Meditation", "Cycling", "Yoga", "Personal Practice"
        )))

        val customId = repository.saveActivity(
            name = "Guitar Practice",
            iconKey = "music_note",
            colorHex = 0xFF7C3AED,
            dailyTargetMinutes = 40,
            description = "Chord transitions and scales"
        )
        assertTrue(customId > 0L)
        assertEquals(13, repository.activities.first().size)
    }

    @Test
    fun `timer manager prevents simultaneous timers and persists completed session`() = runTest {
        repository.ensureDefaultActivitiesSeeded()
        val activities = repository.activities.first()
        val walking = activities.first { it.name == "Walking" }
        val reading = activities.first { it.name == "Reading" }

        val startWalking = timerManager.startActivity(walking)
        assertEquals(StartTimerResult.Started, startWalking)
        assertNotNull(repository.getActiveTimerOnce())

        // Attempting to start Reading while Walking is active returns Conflict
        val conflictResult = timerManager.startActivity(reading)
        assertTrue(conflictResult is StartTimerResult.Conflict)
        assertEquals(walking.id, repository.getActiveTimerOnce()?.activityId)

        // Pause and resume preserve state
        timerManager.pause()
        assertEquals(false, repository.getActiveTimerOnce()?.isRunning)

        timerManager.resume()
        assertEquals(true, repository.getActiveTimerOnce()?.isRunning)

        // Finish and save session permanently
        val savedSession = timerManager.stopAndFinish("Morning park walk")
        assertNotNull(savedSession)
        assertNull(repository.getActiveTimerOnce())
        assertEquals(walking.id, savedSession?.activityId)
        assertEquals("Morning park walk", savedSession?.notes)
        assertTrue((savedSession?.durationMillis ?: 0L) >= 1000L)
        assertEquals(1, repository.allSessions.first().size)
    }

    @Test
    fun `json backup export and restore round-trips activities and sessions`() = runTest {
        repository.ensureDefaultActivitiesSeeded()
        val exercise = repository.activities.first().first { it.name == "Exercise" }

        timerManager.startActivity(exercise)
        timerManager.stopAndFinish("HIIT workout")

        val backupJson = repository.exportBackupJson()
        assertTrue(backupJson.contains("HIIT workout"))

        repository.resetAllData()
        assertEquals(0, repository.allSessions.first().size)

        val restoredResult = repository.importBackupJson(backupJson)
        assertTrue(restoredResult.isSuccess)
        assertEquals(1, restoredResult.getOrNull())
        val restoredSessions = repository.allSessions.first()
        assertEquals(1, restoredSessions.size)
        assertEquals("HIIT workout", restoredSessions.first().notes)
    }
}
