package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        ActivityEntity::class,
        ActivitySessionEntity::class,
        ActiveTimerEntity::class,
        ReminderEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class LifeTrackDatabase : RoomDatabase() {
    abstract fun activityDao(): ActivityDao
    abstract fun sessionDao(): SessionDao
    abstract fun activeTimerDao(): ActiveTimerDao
    abstract fun reminderDao(): ReminderDao

    companion object {
        @Volatile
        private var instance: LifeTrackDatabase? = null

        fun getInstance(context: Context): LifeTrackDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    LifeTrackDatabase::class.java,
                    "lifetrack_database"
                ).build().also { instance = it }
            }

        fun defaultActivities(): List<ActivityEntity> = listOf(
            ActivityEntity(
                name = "Exercise",
                iconKey = "fitness_center",
                colorHex = 0xFF0F766E,
                dailyTargetMinutes = 45,
                description = "Strength, cardio, or daily fitness training",
                isDefault = true,
                sortOrder = 1
            ),
            ActivityEntity(
                name = "Sleep",
                iconKey = "bedtime",
                colorHex = 0xFF4F46E5,
                dailyTargetMinutes = 480,
                description = "Restorative nightly sleep and power naps",
                isDefault = true,
                sortOrder = 2
            ),
            ActivityEntity(
                name = "Walking",
                iconKey = "directions_walk",
                colorHex = 0xFF059669,
                dailyTargetMinutes = 30,
                description = "Outdoor strolls, brisk walks, and daily steps",
                isDefault = true,
                sortOrder = 3
            ),
            ActivityEntity(
                name = "Swimming",
                iconKey = "pool",
                colorHex = 0xFF0284C7,
                dailyTargetMinutes = 45,
                description = "Pool laps, water aerobics, or endurance swim",
                isDefault = true,
                sortOrder = 4
            ),
            ActivityEntity(
                name = "Sports",
                iconKey = "sports_basketball",
                colorHex = 0xFFEA580C,
                dailyTargetMinutes = 60,
                description = "Team sports, court games, and active play",
                isDefault = true,
                sortOrder = 5
            ),
            ActivityEntity(
                name = "Working",
                iconKey = "work",
                colorHex = 0xFF334155,
                dailyTargetMinutes = 240,
                description = "Focused deep work, projects, and tasks",
                isDefault = true,
                sortOrder = 6
            ),
            ActivityEntity(
                name = "Reading",
                iconKey = "menu_book",
                colorHex = 0xFFD97706,
                dailyTargetMinutes = 30,
                description = "Books, articles, and mindful reading time",
                isDefault = true,
                sortOrder = 7
            ),
            ActivityEntity(
                name = "Studying",
                iconKey = "school",
                colorHex = 0xFF7C3AED,
                dailyTargetMinutes = 90,
                description = "Courses, exam prep, homework, and research",
                isDefault = true,
                sortOrder = 8
            ),
            ActivityEntity(
                name = "Meditation",
                iconKey = "self_improvement",
                colorHex = 0xFF0891B2,
                dailyTargetMinutes = 20,
                description = "Breathwork, mindfulness, and quiet reflection",
                isDefault = true,
                sortOrder = 9
            ),
            ActivityEntity(
                name = "Cycling",
                iconKey = "directions_bike",
                colorHex = 0xFF16A34A,
                dailyTargetMinutes = 45,
                description = "Road cycling, trail riding, or indoor bike",
                isDefault = true,
                sortOrder = 10
            ),
            ActivityEntity(
                name = "Yoga",
                iconKey = "spa",
                colorHex = 0xFFDB2777,
                dailyTargetMinutes = 30,
                description = "Flexibility, balance, and restorative flows",
                isDefault = true,
                sortOrder = 11
            ),
            ActivityEntity(
                name = "Personal Practice",
                iconKey = "auto_awesome",
                colorHex = 0xFFB45309,
                dailyTargetMinutes = 30,
                description = "Skill mastery, hobbies, music, or journaling",
                isDefault = true,
                sortOrder = 12
            )
        )
    }
}
