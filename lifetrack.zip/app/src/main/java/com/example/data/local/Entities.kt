package com.example.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
@Entity(tableName = "activities")
data class ActivityEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val iconKey: String,
    val colorHex: Long,
    val dailyTargetMinutes: Int,
    val description: String = "",
    val isDefault: Boolean = false,
    val sortOrder: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

@Serializable
@Entity(
    tableName = "activity_sessions",
    foreignKeys = [
        ForeignKey(
            entity = ActivityEntity::class,
            parentColumns = ["id"],
            childColumns = ["activityId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("activityId"), Index("dateKey")]
)
data class ActivitySessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val activityId: Long,
    val startTimeMillis: Long,
    val endTimeMillis: Long,
    val durationMillis: Long,
    val dateKey: String,
    val notes: String = ""
)

@Entity(tableName = "active_timer")
data class ActiveTimerEntity(
    @PrimaryKey val id: Int = 1,
    val activityId: Long,
    val activityName: String,
    val activityColorHex: Long,
    val activityIconKey: String,
    val originalStartTimeMillis: Long,
    val lastResumeWallTimeMillis: Long,
    val accumulatedDurationMillis: Long,
    val isRunning: Boolean
)

@Serializable
@Entity(
    tableName = "reminders",
    indices = [Index("activityId")]
)
data class ReminderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val activityId: Long? = null,
    val title: String,
    val hour: Int,
    val minute: Int,
    val daysOfWeekMask: Int = 127, // 7 bits: Mon(1) .. Sun(64), 127 = every day
    val isEnabled: Boolean = true
)
