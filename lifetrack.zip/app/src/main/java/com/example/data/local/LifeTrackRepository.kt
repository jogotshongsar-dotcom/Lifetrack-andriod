package com.example.data.local

import androidx.room.withTransaction
import com.example.util.DateTimeUtils
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Serializable
data class LifeTrackBackupPayload(
    val version: Int = 1,
    val exportedAtMillis: Long = System.currentTimeMillis(),
    val preferences: UserPreferences,
    val activities: List<ActivityEntity>,
    val sessions: List<ActivitySessionEntity>,
    val reminders: List<ReminderEntity>
)

class LifeTrackRepository(
    private val database: LifeTrackDatabase,
    private val preferencesRepository: UserPreferencesRepository
) {
    private val activityDao = database.activityDao()
    private val sessionDao = database.sessionDao()
    private val activeTimerDao = database.activeTimerDao()
    private val reminderDao = database.reminderDao()

    private val seedMutex = Mutex()
    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    val activities: Flow<List<ActivityEntity>> = activityDao.observeAll()
    val allSessions: Flow<List<ActivitySessionEntity>> = sessionDao.observeAll()
    val activeTimer: Flow<ActiveTimerEntity?> = activeTimerDao.observeActive()
    val reminders: Flow<List<ReminderEntity>> = reminderDao.observeAll()
    val preferences: Flow<UserPreferences> = preferencesRepository.preferences

    fun observeActivityById(id: Long): Flow<ActivityEntity?> = activityDao.observeById(id)

    fun observeSessionsForDate(dateKey: String): Flow<List<ActivitySessionEntity>> =
        sessionDao.observeByDate(dateKey)

    fun observeSessionsForActivity(activityId: Long): Flow<List<ActivitySessionEntity>> =
        sessionDao.observeByActivity(activityId)

    fun observeSessionsBetween(startDateKey: String, endDateKey: String): Flow<List<ActivitySessionEntity>> =
        sessionDao.observeBetweenDates(startDateKey, endDateKey)

    suspend fun ensureDefaultActivitiesSeeded() {
        seedMutex.withLock {
            if (activityDao.count() == 0) {
                activityDao.insertAll(LifeTrackDatabase.defaultActivities())
            }
        }
    }

    suspend fun getActivityByIdOnce(id: Long): ActivityEntity? = activityDao.getByIdOnce(id)

    suspend fun saveActivity(
        id: Long? = null,
        name: String,
        iconKey: String,
        colorHex: Long,
        dailyTargetMinutes: Int,
        description: String
    ): Long {
        val trimmedName = name.trim()
        require(trimmedName.isNotEmpty()) { "Activity name cannot be empty" }
        val existing = id?.let { activityDao.getByIdOnce(it) }
        return if (existing != null) {
            val updated = existing.copy(
                name = trimmedName,
                iconKey = iconKey,
                colorHex = colorHex,
                dailyTargetMinutes = dailyTargetMinutes.coerceIn(1, 1440),
                description = description.trim()
            )
            activityDao.update(updated)
            updated.id
        } else {
            val currentCount = activityDao.count()
            val newEntity = ActivityEntity(
                name = trimmedName,
                iconKey = iconKey,
                colorHex = colorHex,
                dailyTargetMinutes = dailyTargetMinutes.coerceIn(1, 1440),
                description = description.trim(),
                isDefault = false,
                sortOrder = currentCount + 1
            )
            activityDao.insert(newEntity)
        }
    }

    suspend fun deleteActivity(activityId: Long) {
        val active = activeTimerDao.getActiveOnce()
        if (active?.activityId == activityId) {
            activeTimerDao.clear()
        }
        activityDao.deleteById(activityId)
    }

    suspend fun insertSession(session: ActivitySessionEntity): Long = sessionDao.insert(session)

    suspend fun deleteSession(sessionId: Long) {
        sessionDao.deleteById(sessionId)
    }

    suspend fun getActiveTimerOnce(): ActiveTimerEntity? = activeTimerDao.getActiveOnce()

    suspend fun upsertActiveTimer(timer: ActiveTimerEntity) = activeTimerDao.upsert(timer)

    suspend fun clearActiveTimer() = activeTimerDao.clear()

    suspend fun getAllRemindersOnce(): List<ReminderEntity> = reminderDao.getAllOnce()

    suspend fun getEnabledRemindersOnce(): List<ReminderEntity> = reminderDao.getEnabledOnce()

    suspend fun getReminderByIdOnce(id: Long): ReminderEntity? = reminderDao.getByIdOnce(id)

    suspend fun saveReminder(reminder: ReminderEntity): Long {
        return if (reminder.id == 0L) {
            reminderDao.insert(reminder)
        } else {
            reminderDao.update(reminder)
            reminder.id
        }
    }

    suspend fun deleteReminder(id: Long) = reminderDao.deleteById(id)

    suspend fun updateProfile(name: String, ageGroup: AgeGroup) =
        preferencesRepository.updateProfile(name, ageGroup)

    suspend fun updateDailyGoalMinutes(minutes: Int) =
        preferencesRepository.updateDailyGoalMinutes(minutes)

    suspend fun updateThemeMode(mode: ThemeMode) =
        preferencesRepository.updateThemeMode(mode)

    suspend fun updateNotificationsEnabled(enabled: Boolean) =
        preferencesRepository.updateNotificationsEnabled(enabled)

    suspend fun updateReducedMotion(enabled: Boolean) =
        preferencesRepository.updateReducedMotion(enabled)

    suspend fun exportBackupJson(): String {
        val payload = LifeTrackBackupPayload(
            preferences = preferencesRepository.getOnce(),
            activities = activityDao.getAllOnce(),
            sessions = sessionDao.getAllOnce(),
            reminders = reminderDao.getAllOnce()
        )
        return json.encodeToString(payload)
    }

    suspend fun importBackupJson(rawJson: String): Result<Int> = runCatching {
        val payload = json.decodeFromString<LifeTrackBackupPayload>(rawJson)
        database.withTransaction {
            activeTimerDao.clear()
            sessionDao.deleteAll()
            reminderDao.deleteAll()
            activityDao.deleteAll()

            if (payload.activities.isNotEmpty()) {
                activityDao.insertAll(payload.activities)
            } else {
                activityDao.insertAll(LifeTrackDatabase.defaultActivities())
            }
            val validActivityIds = activityDao.getAllOnce().map { it.id }.toSet()
            val validSessions = payload.sessions.filter { it.activityId in validActivityIds }
            if (validSessions.isNotEmpty()) {
                sessionDao.insertAll(validSessions)
            }
            if (payload.reminders.isNotEmpty()) {
                reminderDao.insertAll(payload.reminders)
            }
        }
        preferencesRepository.restorePreferences(payload.preferences)
        payload.sessions.size
    }

    suspend fun exportSessionsCsv(): String {
        val activitiesMap = activityDao.getAllOnce().associateBy { it.id }
        val sessions = sessionDao.getAllOnce()
        val sb = StringBuilder()
        sb.appendLine("Date,Activity,Start Time,Finish Time,Duration (Minutes),Duration (HH:MM:SS),Notes")
        sessions.forEach { session ->
            val activityName = (activitiesMap[session.activityId]?.name ?: "Activity")
                .replace("\"", "\"\"")
            val startStr = DateTimeUtils.formatTime(session.startTimeMillis)
            val endStr = DateTimeUtils.formatTime(session.endTimeMillis)
            val minutes = (session.durationMillis / 60_000.0)
            val hms = DateTimeUtils.formatHms(session.durationMillis)
            val notes = session.notes.replace("\"", "\"\"").replace("\n", " ")
            sb.appendLine(
                "${session.dateKey},\"$activityName\",\"$startStr\",\"$endStr\",${
                    String.format(java.util.Locale.US, "%.1f", minutes)
                },\"$hms\",\"$notes\""
            )
        }
        return sb.toString()
    }

    suspend fun buildPlainTextSummary(days: Int = 7): String {
        val activitiesMap = activityDao.getAllOnce().associateBy { it.id }
        val dateKeys = DateTimeUtils.getLastNDaysKeys(days)
        val sessions = sessionDao.getAllOnce().filter { it.dateKey in dateKeys }
        val totalMs = sessions.sumOf { it.durationMillis }
        val sb = StringBuilder()
        sb.appendLine("LifeTrack Practice Summary (Last $days Days)")
        sb.appendLine("Total Practice Time: ${DateTimeUtils.formatCompactDuration(totalMs)}")
        sb.appendLine("Total Sessions: ${sessions.size}")
        sb.appendLine()
        val grouped = sessions.groupBy { it.activityId }
            .mapValues { (_, list) -> list.sumOf { it.durationMillis } }
            .entries.sortedByDescending { it.value }
        grouped.forEach { (id, ms) ->
            val name = activitiesMap[id]?.name ?: "Activity"
            sb.appendLine("• $name: ${DateTimeUtils.formatCompactDuration(ms)}")
        }
        return sb.toString().trim()
    }

    suspend fun resetSessionsOnly() {
        database.withTransaction {
            activeTimerDao.clear()
            sessionDao.deleteAll()
        }
    }

    suspend fun resetAllData() {
        database.withTransaction {
            activeTimerDao.clear()
            sessionDao.deleteAll()
            reminderDao.deleteAll()
            activityDao.deleteAll()
            activityDao.insertAll(LifeTrackDatabase.defaultActivities())
        }
        preferencesRepository.resetToDefaults()
    }
}
