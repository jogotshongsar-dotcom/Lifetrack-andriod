package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ActivityDao {
    @Query("SELECT * FROM activities ORDER BY sortOrder ASC, createdAt ASC")
    fun observeAll(): Flow<List<ActivityEntity>>

    @Query("SELECT * FROM activities ORDER BY sortOrder ASC, createdAt ASC")
    suspend fun getAllOnce(): List<ActivityEntity>

    @Query("SELECT * FROM activities WHERE id = :id LIMIT 1")
    fun observeById(id: Long): Flow<ActivityEntity?>

    @Query("SELECT * FROM activities WHERE id = :id LIMIT 1")
    suspend fun getByIdOnce(id: Long): ActivityEntity?

    @Query("SELECT COUNT(*) FROM activities")
    suspend fun count(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(activity: ActivityEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(activities: List<ActivityEntity>): List<Long>

    @Update
    suspend fun update(activity: ActivityEntity)

    @Query("DELETE FROM activities WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM activities")
    suspend fun deleteAll()
}

@Dao
interface SessionDao {
    @Query("SELECT * FROM activity_sessions ORDER BY startTimeMillis DESC")
    fun observeAll(): Flow<List<ActivitySessionEntity>>

    @Query("SELECT * FROM activity_sessions ORDER BY startTimeMillis DESC")
    suspend fun getAllOnce(): List<ActivitySessionEntity>

    @Query("SELECT * FROM activity_sessions WHERE dateKey = :dateKey ORDER BY startTimeMillis DESC")
    fun observeByDate(dateKey: String): Flow<List<ActivitySessionEntity>>

    @Query("SELECT * FROM activity_sessions WHERE dateKey BETWEEN :startDateKey AND :endDateKey ORDER BY startTimeMillis DESC")
    fun observeBetweenDates(startDateKey: String, endDateKey: String): Flow<List<ActivitySessionEntity>>

    @Query("SELECT * FROM activity_sessions WHERE activityId = :activityId ORDER BY startTimeMillis DESC")
    fun observeByActivity(activityId: Long): Flow<List<ActivitySessionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(session: ActivitySessionEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(sessions: List<ActivitySessionEntity>)

    @Query("DELETE FROM activity_sessions WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM activity_sessions")
    suspend fun deleteAll()
}

@Dao
interface ActiveTimerDao {
    @Query("SELECT * FROM active_timer WHERE id = 1 LIMIT 1")
    fun observeActive(): Flow<ActiveTimerEntity?>

    @Query("SELECT * FROM active_timer WHERE id = 1 LIMIT 1")
    suspend fun getActiveOnce(): ActiveTimerEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(timer: ActiveTimerEntity)

    @Query("DELETE FROM active_timer WHERE id = 1")
    suspend fun clear()
}

@Dao
interface ReminderDao {
    @Query("SELECT * FROM reminders ORDER BY hour ASC, minute ASC")
    fun observeAll(): Flow<List<ReminderEntity>>

    @Query("SELECT * FROM reminders ORDER BY hour ASC, minute ASC")
    suspend fun getAllOnce(): List<ReminderEntity>

    @Query("SELECT * FROM reminders WHERE isEnabled = 1")
    suspend fun getEnabledOnce(): List<ReminderEntity>

    @Query("SELECT * FROM reminders WHERE id = :id LIMIT 1")
    suspend fun getByIdOnce(id: Long): ReminderEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(reminder: ReminderEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(reminders: List<ReminderEntity>)

    @Update
    suspend fun update(reminder: ReminderEntity)

    @Query("DELETE FROM reminders WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM reminders")
    suspend fun deleteAll()
}
