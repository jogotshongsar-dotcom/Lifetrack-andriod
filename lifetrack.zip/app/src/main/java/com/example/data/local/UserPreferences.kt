package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.Serializable

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "lifetrack_prefs")

@Serializable
enum class ThemeMode(val label: String) {
    SYSTEM("System Default"),
    LIGHT("Light Theme"),
    DARK("Dark Theme")
}

@Serializable
enum class AgeGroup(val label: String, val tagline: String) {
    UNSPECIFIED("All Ages", "Balanced daily practice for every stage"),
    CHILD("Kids & Youth", "Fun, healthy habits for play, reading & rest"),
    STUDENT("Student", "Focus blocks for study, reading & sports"),
    ADULT("Adult", "Consistent wellness, movement & personal growth"),
    PROFESSIONAL("Professional", "Deep work, active breaks & restorative sleep"),
    SENIOR("Senior", "Gentle daily walking, mindfulness & joyful hobbies")
}

@Serializable
data class UserPreferences(
    val userName: String = "Friend",
    val ageGroup: AgeGroup = AgeGroup.UNSPECIFIED,
    val overallDailyGoalMinutes: Int = 120,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val notificationsEnabled: Boolean = true,
    val reducedMotion: Boolean = false
)

class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val USER_NAME = stringPreferencesKey("user_name")
        val AGE_GROUP = stringPreferencesKey("age_group")
        val DAILY_GOAL_MINUTES = intPreferencesKey("daily_goal_minutes")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val NOTIFICATIONS_ENABLED = booleanPreferencesKey("notifications_enabled")
        val REDUCED_MOTION = booleanPreferencesKey("reduced_motion")
    }

    val preferences: Flow<UserPreferences> = context.dataStore.data.map { prefs ->
        UserPreferences(
            userName = prefs[Keys.USER_NAME] ?: "Friend",
            ageGroup = prefs[Keys.AGE_GROUP]?.let { name ->
                AgeGroup.entries.firstOrNull { it.name == name }
            } ?: AgeGroup.UNSPECIFIED,
            overallDailyGoalMinutes = prefs[Keys.DAILY_GOAL_MINUTES] ?: 120,
            themeMode = prefs[Keys.THEME_MODE]?.let { name ->
                ThemeMode.entries.firstOrNull { it.name == name }
            } ?: ThemeMode.SYSTEM,
            notificationsEnabled = prefs[Keys.NOTIFICATIONS_ENABLED] ?: true,
            reducedMotion = prefs[Keys.REDUCED_MOTION] ?: false
        )
    }

    suspend fun getOnce(): UserPreferences = preferences.first()

    suspend fun updateProfile(userName: String, ageGroup: AgeGroup) {
        context.dataStore.edit { prefs ->
            prefs[Keys.USER_NAME] = userName.trim().ifEmpty { "Friend" }
            prefs[Keys.AGE_GROUP] = ageGroup.name
        }
    }

    suspend fun updateDailyGoalMinutes(minutes: Int) {
        context.dataStore.edit { prefs ->
            prefs[Keys.DAILY_GOAL_MINUTES] = minutes.coerceIn(15, 1440)
        }
    }

    suspend fun updateThemeMode(mode: ThemeMode) {
        context.dataStore.edit { prefs ->
            prefs[Keys.THEME_MODE] = mode.name
        }
    }

    suspend fun updateNotificationsEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.NOTIFICATIONS_ENABLED] = enabled
        }
    }

    suspend fun updateReducedMotion(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.REDUCED_MOTION] = enabled
        }
    }

    suspend fun restorePreferences(userPreferences: UserPreferences) {
        context.dataStore.edit { prefs ->
            prefs[Keys.USER_NAME] = userPreferences.userName
            prefs[Keys.AGE_GROUP] = userPreferences.ageGroup.name
            prefs[Keys.DAILY_GOAL_MINUTES] = userPreferences.overallDailyGoalMinutes
            prefs[Keys.THEME_MODE] = userPreferences.themeMode.name
            prefs[Keys.NOTIFICATIONS_ENABLED] = userPreferences.notificationsEnabled
            prefs[Keys.REDUCED_MOTION] = userPreferences.reducedMotion
        }
    }

    suspend fun resetToDefaults() {
        restorePreferences(UserPreferences())
    }
}
