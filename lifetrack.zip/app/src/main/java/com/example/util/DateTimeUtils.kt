package com.example.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.max

object DateTimeUtils {

    private val dateKeyFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private val monthTitleFormat = SimpleDateFormat("MMMM yyyy", Locale.getDefault())
    private val shortDateFormat = SimpleDateFormat("EEE, MMM d", Locale.getDefault())
    private val fullDateFormat = SimpleDateFormat("EEEE, MMM d, yyyy", Locale.getDefault())
    private val timeFormat = SimpleDateFormat("h:mm a", Locale.getDefault())
    private val monthDayFormat = SimpleDateFormat("MMM d", Locale.getDefault())
    private val weekdayShortFormat = SimpleDateFormat("EEE", Locale.getDefault())

    @Synchronized
    fun toDateKey(millis: Long = System.currentTimeMillis()): String =
        dateKeyFormat.format(Date(millis))

    @Synchronized
    fun parseDateKey(dateKey: String): Calendar {
        val cal = Calendar.getInstance()
        val parsed = runCatching { dateKeyFormat.parse(dateKey) }.getOrNull()
        if (parsed != null) {
            cal.time = parsed
        }
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal
    }

    fun shiftDateKey(dateKey: String, daysDelta: Int): String {
        val cal = parseDateKey(dateKey)
        cal.add(Calendar.DAY_OF_YEAR, daysDelta)
        return toDateKey(cal.timeInMillis)
    }

    fun shiftMonth(year: Int, monthZeroIndexed: Int, deltaMonths: Int): Pair<Int, Int> {
        val cal = Calendar.getInstance().apply {
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, monthZeroIndexed)
            set(Calendar.DAY_OF_MONTH, 1)
            add(Calendar.MONTH, deltaMonths)
        }
        return cal.get(Calendar.YEAR) to cal.get(Calendar.MONTH)
    }

    fun currentYearMonth(): Pair<Int, Int> {
        val cal = Calendar.getInstance()
        return cal.get(Calendar.YEAR) to cal.get(Calendar.MONTH)
    }

    @Synchronized
    fun formatMonthTitle(year: Int, monthZeroIndexed: Int): String {
        val cal = Calendar.getInstance().apply {
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, monthZeroIndexed)
            set(Calendar.DAY_OF_MONTH, 1)
        }
        return monthTitleFormat.format(cal.time)
    }

    @Synchronized
    fun formatShortDate(dateKey: String): String =
        shortDateFormat.format(parseDateKey(dateKey).time)

    @Synchronized
    fun formatFullDate(dateKey: String): String =
        fullDateFormat.format(parseDateKey(dateKey).time)

    @Synchronized
    fun formatTime(millis: Long): String =
        timeFormat.format(Date(millis))

    @Synchronized
    fun formatTimeOfDay(hour: Int, minute: Int): String {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
        }
        return timeFormat.format(cal.time)
    }

    @Synchronized
    fun formatMonthDay(dateKey: String): String =
        monthDayFormat.format(parseDateKey(dateKey).time)

    @Synchronized
    fun formatWeekdayShort(dateKey: String): String =
        weekdayShortFormat.format(parseDateKey(dateKey).time)

    fun formatHms(durationMillis: Long): String {
        val totalSeconds = max(0L, durationMillis / 1000L)
        val hours = totalSeconds / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L
        return String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
    }

    fun formatCompactDuration(durationMillis: Long): String {
        val totalSeconds = max(0L, durationMillis / 1000L)
        val totalMinutes = totalSeconds / 60L
        val hours = totalMinutes / 60L
        val minutes = totalMinutes % 60L
        return when {
            hours > 0 && minutes > 0 -> "${hours}h ${minutes}m"
            hours > 0 -> "${hours}h"
            totalMinutes > 0 -> "${totalMinutes}m"
            totalSeconds > 0 -> "${totalSeconds}s"
            else -> "0m"
        }
    }

    fun formatMinutesReadable(minutes: Int): String {
        val safe = max(0, minutes)
        val h = safe / 60
        val m = safe % 60
        return when {
            h > 0 && m > 0 -> "${h}h ${m}m"
            h > 0 -> "${h}h"
            else -> "${m}m"
        }
    }

    fun getLastNDaysKeys(n: Int, endDateKey: String = toDateKey()): List<String> {
        return (-(n - 1)..0).map { offset -> shiftDateKey(endDateKey, offset) }
    }

    fun getWeekRangeForDate(dateKey: String): Pair<String, String> {
        val cal = parseDateKey(dateKey)
        cal.firstDayOfWeek = Calendar.MONDAY
        val dayOfWeek = cal.get(Calendar.DAY_OF_WEEK)
        val diffFromMonday = when (dayOfWeek) {
            Calendar.SUNDAY -> 6
            else -> dayOfWeek - Calendar.MONDAY
        }
        cal.add(Calendar.DAY_OF_YEAR, -diffFromMonday)
        val start = toDateKey(cal.timeInMillis)
        cal.add(Calendar.DAY_OF_YEAR, 6)
        val end = toDateKey(cal.timeInMillis)
        return start to end
    }

    fun getDaysInWeek(dateKey: String): List<String> {
        val (start, _) = getWeekRangeForDate(dateKey)
        return (0..6).map { shiftDateKey(start, it) }
    }

    fun getMonthRange(year: Int, monthZeroIndexed: Int): Pair<String, String> {
        val cal = Calendar.getInstance().apply {
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, monthZeroIndexed)
            set(Calendar.DAY_OF_MONTH, 1)
        }
        val start = toDateKey(cal.timeInMillis)
        val maxDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        cal.set(Calendar.DAY_OF_MONTH, maxDay)
        val end = toDateKey(cal.timeInMillis)
        return start to end
    }

    /**
     * Returns a 42-cell (or 35-cell) list of nullable dateKeys starting on Monday for calendar grid rendering.
     */
    fun getMonthCalendarCells(year: Int, monthZeroIndexed: Int): List<String?> {
        val cal = Calendar.getInstance().apply {
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, monthZeroIndexed)
            set(Calendar.DAY_OF_MONTH, 1)
        }
        val firstDayOfWeek = cal.get(Calendar.DAY_OF_WEEK)
        val leadingEmpty = when (firstDayOfWeek) {
            Calendar.SUNDAY -> 6
            else -> firstDayOfWeek - Calendar.MONDAY
        }
        val daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        val cells = mutableListOf<String?>()
        repeat(leadingEmpty) { cells.add(null) }
        for (day in 1..daysInMonth) {
            cal.set(Calendar.DAY_OF_MONTH, day)
            cells.add(toDateKey(cal.timeInMillis))
        }
        while (cells.size % 7 != 0) {
            cells.add(null)
        }
        return cells
    }

    fun dayNumberOfDateKey(dateKey: String): Int =
        parseDateKey(dateKey).get(Calendar.DAY_OF_MONTH)

    fun greetingForHour(hour: Int = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)): String =
        when (hour) {
            in 4..11 -> "Good Morning"
            in 12..16 -> "Good Afternoon"
            in 17..20 -> "Good Evening"
            else -> "Good Night"
        }

    /**
     * Converts Calendar.DAY_OF_WEEK (Sun=1..Sat=7) into bit index 0..6 where Mon=0..Sun=6.
     */
    fun calendarDayToMaskBit(calendarDayOfWeek: Int): Int = when (calendarDayOfWeek) {
        Calendar.MONDAY -> 0
        Calendar.TUESDAY -> 1
        Calendar.WEDNESDAY -> 2
        Calendar.THURSDAY -> 3
        Calendar.FRIDAY -> 4
        Calendar.SATURDAY -> 5
        Calendar.SUNDAY -> 6
        else -> 0
    }
}
