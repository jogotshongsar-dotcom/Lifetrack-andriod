package com.example.util

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.Brush
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.DirectionsBike
import androidx.compose.material.icons.rounded.DirectionsRun
import androidx.compose.material.icons.rounded.DirectionsWalk
import androidx.compose.material.icons.rounded.FitnessCenter
import androidx.compose.material.icons.rounded.Hiking
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pets
import androidx.compose.material.icons.rounded.Pool
import androidx.compose.material.icons.rounded.Psychology
import androidx.compose.material.icons.rounded.Restaurant
import androidx.compose.material.icons.rounded.School
import androidx.compose.material.icons.rounded.SelfImprovement
import androidx.compose.material.icons.rounded.Spa
import androidx.compose.material.icons.rounded.SportsBasketball
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.VolunteerActivism
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.material.icons.rounded.Work
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

data class ActivityIconOption(
    val key: String,
    val label: String,
    val icon: ImageVector
)

object ActivityIconCatalog {
    val options: List<ActivityIconOption> = listOf(
        ActivityIconOption("fitness_center", "Exercise", Icons.Rounded.FitnessCenter),
        ActivityIconOption("bedtime", "Sleep", Icons.Rounded.Bedtime),
        ActivityIconOption("directions_walk", "Walking", Icons.Rounded.DirectionsWalk),
        ActivityIconOption("pool", "Swimming", Icons.Rounded.Pool),
        ActivityIconOption("sports_basketball", "Sports", Icons.Rounded.SportsBasketball),
        ActivityIconOption("work", "Working", Icons.Rounded.Work),
        ActivityIconOption("menu_book", "Reading", Icons.Rounded.MenuBook),
        ActivityIconOption("school", "Studying", Icons.Rounded.School),
        ActivityIconOption("self_improvement", "Meditation", Icons.Rounded.SelfImprovement),
        ActivityIconOption("directions_bike", "Cycling", Icons.Rounded.DirectionsBike),
        ActivityIconOption("spa", "Yoga", Icons.Rounded.Spa),
        ActivityIconOption("auto_awesome", "Practice", Icons.Rounded.AutoAwesome),
        ActivityIconOption("directions_run", "Running", Icons.Rounded.DirectionsRun),
        ActivityIconOption("hiking", "Hiking", Icons.Rounded.Hiking),
        ActivityIconOption("brush", "Art & Craft", Icons.Rounded.Brush),
        ActivityIconOption("music_note", "Music", Icons.Rounded.MusicNote),
        ActivityIconOption("code", "Coding", Icons.Rounded.Code),
        ActivityIconOption("psychology", "Mind", Icons.Rounded.Psychology),
        ActivityIconOption("restaurant", "Cooking", Icons.Rounded.Restaurant),
        ActivityIconOption("water_drop", "Hydration", Icons.Rounded.WaterDrop),
        ActivityIconOption("language", "Language", Icons.Rounded.Language),
        ActivityIconOption("volunteer_activism", "Care", Icons.Rounded.VolunteerActivism),
        ActivityIconOption("home", "Chores", Icons.Rounded.Home),
        ActivityIconOption("pets", "Pet Care", Icons.Rounded.Pets)
    )

    val colorSwatches: List<Long> = listOf(
        0xFF0F766E, // Forest Teal
        0xFF059669, // Emerald Sage
        0xFF0284C7, // Ocean Blue
        0xFF4F46E5, // Deep Indigo
        0xFF7C3AED, // Royal Violet
        0xFFDB2777, // Rose Berry
        0xFFEA580C, // Warm Terracotta
        0xFFD97706, // Amber Gold
        0xFF16A34A, // Meadow Green
        0xFF0891B2, // Tranquil Cyan
        0xFF334155, // Slate Ink
        0xFFB45309  // Warm Ochre
    )

    fun iconForKey(key: String): ImageVector =
        options.firstOrNull { it.key == key }?.icon ?: Icons.Rounded.Timer

    fun colorFromHex(hex: Long): Color = Color(hex)
}
