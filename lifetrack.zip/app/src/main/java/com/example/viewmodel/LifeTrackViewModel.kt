package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.LifeTrackApplication
import com.example.data.local.ActivityEntity
import com.example.data.local.ActivitySessionEntity
import com.example.data.local.AgeGroup
import com.example.data.local.ReminderEntity
import com.example.data.local.ThemeMode
import com.example.data.local.UserPreferences
import com.example.service.ActiveTimerSnapshot
import com.example.service.StartTimerResult
import com.example.util.DateTimeUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.min

data class ActivityWithProgress(
    val activity: ActivityEntity,
    val loggedMillisToday: Long,
    val sessionsCountToday: Int,
    val isCurrentlyActive: Boolean
) {
    val targetMillis: Long get() = activity.dailyTargetMinutes * 60_000L
    val progressFraction: Float
        get() = if (targetMillis <= 0L) 0f else (loggedMillisToday.toFloat() / targetMillis.toFloat()).coerceIn(0f, 1f)
    val isGoalCompleted: Boolean get() = loggedMillisToday >= targetMillis && targetMillis > 0L
}

data class SessionDisplayItem(
    val session: ActivitySessionEntity,
    val activityName: String,
    val activityColorHex: Long,
    val activityIconKey: String
)

data class DashboardUiState(
    val userName: String = "Friend",
    val ageGroup: AgeGroup = AgeGroup.UNSPECIFIED,
    val greeting: String = DateTimeUtils.greetingForHour(),
    val todayDateLabel: String = DateTimeUtils.formatFullDate(DateTimeUtils.toDateKey()),
    val todayTotalMillis: Long = 0L,
    val overallDailyGoalMinutes: Int = 120,
    val dailyProgressFraction: Float = 0f,
    val completedGoalsCount: Int = 0,
    val totalActivitiesCount: Int = 0,
    val exerciseMillis: Long = 0L,
    val sleepMillis: Long = 0L,
    val walkingMillis: Long = 0L,
    val activeTimer: ActiveTimerSnapshot? = null,
    val quickActivities: List<ActivityWithProgress> = emptyList(),
    val todaySessions: List<SessionDisplayItem> = emptyList()
)

enum class ActivityFilterMode(val label: String) {
    ALL("All"),
    COMPLETED("Goals Met"),
    CUSTOM("Custom")
}

data class ActivitiesUiState(
    val searchQuery: String = "",
    val filterMode: ActivityFilterMode = ActivityFilterMode.ALL,
    val items: List<ActivityWithProgress> = emptyList(),
    val activeTimer: ActiveTimerSnapshot? = null
)

enum class CalendarViewMode(val label: String) {
    DAY("Daily"),
    WEEK("Weekly"),
    MONTH("Monthly")
}

data class ActivityReportRow(
    val activity: ActivityEntity,
    val totalMillis: Long,
    val targetMillis: Long,
    val sessionCount: Int,
    val isGoalMet: Boolean
)

data class CalendarUiState(
    val year: Int = DateTimeUtils.currentYearMonth().first,
    val monthZeroIndexed: Int = DateTimeUtils.currentYearMonth().second,
    val monthTitle: String = DateTimeUtils.formatMonthTitle(
        DateTimeUtils.currentYearMonth().first,
        DateTimeUtils.currentYearMonth().second
    ),
    val selectedDateKey: String = DateTimeUtils.toDateKey(),
    val viewMode: CalendarViewMode = CalendarViewMode.DAY,
    val calendarCells: List<String?> = DateTimeUtils.getMonthCalendarCells(
        DateTimeUtils.currentYearMonth().first,
        DateTimeUtils.currentYearMonth().second
    ),
    val activeDateMarkers: Map<String, Long> = emptyMap(),
    val periodTotalMillis: Long = 0L,
    val completedGoalsCount: Int = 0,
    val unfinishedGoalsCount: Int = 0,
    val activityReports: List<ActivityReportRow> = emptyList(),
    val sessions: List<SessionDisplayItem> = emptyList()
)

enum class StatsTimeframe(val label: String, val daysCount: Int) {
    TODAY("Today", 1),
    WEEK("7 Days", 7),
    MONTH("30 Days", 30)
}

data class DailyChartPoint(
    val dateKey: String,
    val shortLabel: String,
    val totalMinutes: Float
)

data class ActivityStatComparison(
    val activity: ActivityEntity,
    val totalMillis: Long,
    val shareFraction: Float,
    val goalAdherencePercent: Int,
    val sessionsCount: Int
)

data class StatisticsUiState(
    val timeframe: StatsTimeframe = StatsTimeframe.WEEK,
    val totalMillis: Long = 0L,
    val averageDailyMillis: Long = 0L,
    val goalCompletionPercent: Int = 0,
    val activeDaysCount: Int = 0,
    val totalSessionsCount: Int = 0,
    val weeklyBarPoints: List<DailyChartPoint> = emptyList(),
    val monthlyTrendPoints: List<DailyChartPoint> = emptyList(),
    val dailyGoalMinutes: Int = 120,
    val activityComparisons: List<ActivityStatComparison> = emptyList()
)

data class SettingsUiState(
    val preferences: UserPreferences = UserPreferences(),
    val reminders: List<ReminderEntity> = emptyList(),
    val activities: List<ActivityEntity> = emptyList(),
    val totalSessionsCount: Int = 0
)

class LifeTrackViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as LifeTrackApplication
    private val repository = app.repository
    private val timerManager = app.timerManager
    private val reminderScheduler = app.reminderScheduler

    private val searchQuery = MutableStateFlow("")
    private val activityFilterMode = MutableStateFlow(ActivityFilterMode.ALL)
    private val selectedDateKey = MutableStateFlow(DateTimeUtils.toDateKey())
    private val calendarYearMonth = MutableStateFlow(DateTimeUtils.currentYearMonth())
    private val calendarViewMode = MutableStateFlow(CalendarViewMode.DAY)
    private val statsTimeframe = MutableStateFlow(StatsTimeframe.WEEK)

    private val _timerConflict = MutableStateFlow<StartTimerResult.Conflict?>(null)
    val timerConflict: StateFlow<StartTimerResult.Conflict?> = _timerConflict.asStateFlow()

    private val _uiMessages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val uiMessages: SharedFlow<String> = _uiMessages.asSharedFlow()

    val activeTimerState: StateFlow<ActiveTimerSnapshot?> = timerManager.activeTimerState
    val preferencesState: StateFlow<UserPreferences> = repository.preferences
        .stateIn(viewModelScope, SharingStarted.Eagerly, UserPreferences())

    val allActivities: StateFlow<List<ActivityEntity>> = repository.activities
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val dashboardState: StateFlow<DashboardUiState> = combine(
        repository.preferences,
        repository.activities,
        repository.allSessions,
        timerManager.activeTimerState
    ) { prefs, activities, allSessions, activeTimer ->
        val todayKey = DateTimeUtils.toDateKey()
        val todaySessions = allSessions.filter { it.dateKey == todayKey }
        val activityMap = activities.associateBy { it.id }

        val durationByActivity = mutableMapOf<Long, Long>()
        val countByActivity = mutableMapOf<Long, Int>()
        todaySessions.forEach { session ->
            durationByActivity[session.activityId] =
                (durationByActivity[session.activityId] ?: 0L) + session.durationMillis
            countByActivity[session.activityId] =
                (countByActivity[session.activityId] ?: 0) + 1
        }
        // Include live running/paused timer time for today's live dashboard feel
        if (activeTimer != null && DateTimeUtils.toDateKey(activeTimer.originalStartTimeMillis) == todayKey) {
            durationByActivity[activeTimer.activityId] =
                (durationByActivity[activeTimer.activityId] ?: 0L) + activeTimer.currentElapsedMillis
        }

        val withProgress = activities.map { activity ->
            ActivityWithProgress(
                activity = activity,
                loggedMillisToday = durationByActivity[activity.id] ?: 0L,
                sessionsCountToday = countByActivity[activity.id] ?: 0,
                isCurrentlyActive = activeTimer?.activityId == activity.id
            )
        }

        val todayTotalMillis = durationByActivity.values.sum()
        val dailyGoalMillis = prefs.overallDailyGoalMinutes * 60_000L
        val dailyProgress = if (dailyGoalMillis > 0L) {
            (todayTotalMillis.toFloat() / dailyGoalMillis.toFloat()).coerceIn(0f, 1f)
        } else 0f

        val exerciseMillis = withProgress
            .filter {
                it.activity.name.equals("Exercise", ignoreCase = true) ||
                    it.activity.iconKey == "fitness_center"
            }
            .sumOf { it.loggedMillisToday }

        val sleepMillis = withProgress
            .filter {
                it.activity.name.equals("Sleep", ignoreCase = true) ||
                    it.activity.iconKey == "bedtime"
            }
            .sumOf { it.loggedMillisToday }

        val walkingMillis = withProgress
            .filter {
                it.activity.name.equals("Walking", ignoreCase = true) ||
                    it.activity.iconKey == "directions_walk"
            }
            .sumOf { it.loggedMillisToday }

        val displaySessions = todaySessions.map { session ->
            val act = activityMap[session.activityId]
            SessionDisplayItem(
                session = session,
                activityName = act?.name ?: "Activity",
                activityColorHex = act?.colorHex ?: 0xFF0F766E,
                activityIconKey = act?.iconKey ?: "auto_awesome"
            )
        }

        DashboardUiState(
            userName = prefs.userName,
            ageGroup = prefs.ageGroup,
            greeting = DateTimeUtils.greetingForHour(),
            todayDateLabel = DateTimeUtils.formatFullDate(todayKey),
            todayTotalMillis = todayTotalMillis,
            overallDailyGoalMinutes = prefs.overallDailyGoalMinutes,
            dailyProgressFraction = dailyProgress,
            completedGoalsCount = withProgress.count { it.isGoalCompleted },
            totalActivitiesCount = activities.size,
            exerciseMillis = exerciseMillis,
            sleepMillis = sleepMillis,
            walkingMillis = walkingMillis,
            activeTimer = activeTimer,
            quickActivities = withProgress,
            todaySessions = displaySessions
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardUiState())

    val activitiesState: StateFlow<ActivitiesUiState> = combine(
        repository.activities,
        repository.allSessions,
        timerManager.activeTimerState,
        searchQuery,
        activityFilterMode
    ) { activities, sessions, activeTimer, query, filter ->
        val todayKey = DateTimeUtils.toDateKey()
        val todaySessions = sessions.filter { it.dateKey == todayKey }
        val durationMap = todaySessions.groupBy { it.activityId }
            .mapValues { (_, list) -> list.sumOf { it.durationMillis } }
            .toMutableMap()
        val countMap = todaySessions.groupBy { it.activityId }
            .mapValues { (_, list) -> list.size }

        if (activeTimer != null && DateTimeUtils.toDateKey(activeTimer.originalStartTimeMillis) == todayKey) {
            durationMap[activeTimer.activityId] =
                (durationMap[activeTimer.activityId] ?: 0L) + activeTimer.currentElapsedMillis
        }

        val allItems = activities.map { activity ->
            ActivityWithProgress(
                activity = activity,
                loggedMillisToday = durationMap[activity.id] ?: 0L,
                sessionsCountToday = countMap[activity.id] ?: 0,
                isCurrentlyActive = activeTimer?.activityId == activity.id
            )
        }

        val filtered = allItems.filter { item ->
            val matchesQuery = query.isBlank() ||
                item.activity.name.contains(query, ignoreCase = true) ||
                item.activity.description.contains(query, ignoreCase = true)
            val matchesMode = when (filter) {
                ActivityFilterMode.ALL -> true
                ActivityFilterMode.COMPLETED -> item.isGoalCompleted
                ActivityFilterMode.CUSTOM -> !item.activity.isDefault
            }
            matchesQuery && matchesMode
        }

        ActivitiesUiState(
            searchQuery = query,
            filterMode = filter,
            items = filtered,
            activeTimer = activeTimer
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ActivitiesUiState())

    val calendarState: StateFlow<CalendarUiState> = combine(
        repository.activities,
        repository.allSessions,
        selectedDateKey,
        calendarYearMonth,
        calendarViewMode
    ) { activities, allSessions, selectedDate, yearMonth, viewMode ->
        val (year, month) = yearMonth
        val activityMap = activities.associateBy { it.id }

        val (periodStart, periodEnd, daysInPeriod) = when (viewMode) {
            CalendarViewMode.DAY -> Triple(selectedDate, selectedDate, 1)
            CalendarViewMode.WEEK -> {
                val (s, e) = DateTimeUtils.getWeekRangeForDate(selectedDate)
                Triple(s, e, 7)
            }
            CalendarViewMode.MONTH -> {
                val (s, e) = DateTimeUtils.getMonthRange(year, month)
                val cal = DateTimeUtils.parseDateKey(s)
                val maxDay = cal.getActualMaximum(java.util.Calendar.DAY_OF_MONTH)
                Triple(s, e, maxDay)
            }
        }

        val periodSessions = allSessions.filter { it.dateKey in periodStart..periodEnd }
        val durationByActivity = periodSessions.groupBy { it.activityId }
            .mapValues { (_, list) -> list.sumOf { it.durationMillis } }
        val countByActivity = periodSessions.groupBy { it.activityId }
            .mapValues { (_, list) -> list.size }

        val reports = activities.map { activity ->
            val totalMs = durationByActivity[activity.id] ?: 0L
            val targetMs = activity.dailyTargetMinutes * 60_000L * daysInPeriod
            ActivityReportRow(
                activity = activity,
                totalMillis = totalMs,
                targetMillis = targetMs,
                sessionCount = countByActivity[activity.id] ?: 0,
                isGoalMet = targetMs > 0L && totalMs >= targetMs
            )
        }.sortedWith(compareByDescending<ActivityReportRow> { it.totalMillis }.thenBy { it.activity.sortOrder })

        val (monthStart, monthEnd) = DateTimeUtils.getMonthRange(year, month)
        val markers = allSessions
            .filter { it.dateKey in monthStart..monthEnd }
            .groupBy { it.dateKey }
            .mapValues { (_, list) -> list.sumOf { it.durationMillis } }

        val displaySessions = periodSessions.map { session ->
            val act = activityMap[session.activityId]
            SessionDisplayItem(
                session = session,
                activityName = act?.name ?: "Activity",
                activityColorHex = act?.colorHex ?: 0xFF0F766E,
                activityIconKey = act?.iconKey ?: "auto_awesome"
            )
        }

        CalendarUiState(
            year = year,
            monthZeroIndexed = month,
            monthTitle = DateTimeUtils.formatMonthTitle(year, month),
            selectedDateKey = selectedDate,
            viewMode = viewMode,
            calendarCells = DateTimeUtils.getMonthCalendarCells(year, month),
            activeDateMarkers = markers,
            periodTotalMillis = periodSessions.sumOf { it.durationMillis },
            completedGoalsCount = reports.count { it.isGoalMet },
            unfinishedGoalsCount = reports.count { !it.isGoalMet },
            activityReports = reports,
            sessions = displaySessions
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), CalendarUiState())

    val statisticsState: StateFlow<StatisticsUiState> = combine(
        repository.preferences,
        repository.activities,
        repository.allSessions,
        statsTimeframe
    ) { prefs, activities, allSessions, timeframe ->
        val todayKey = DateTimeUtils.toDateKey()
        val timeframeKeys = DateTimeUtils.getLastNDaysKeys(timeframe.daysCount, todayKey)
        val startKey = timeframeKeys.first()
        val scopedSessions = allSessions.filter { it.dateKey in startKey..todayKey }

        val totalMillis = scopedSessions.sumOf { it.durationMillis }
        val activeDays = scopedSessions.map { it.dateKey }.distinct().size
        val averageMillis = totalMillis / timeframe.daysCount.coerceAtLeast(1)

        val expectedGoalTotalMillis = prefs.overallDailyGoalMinutes * 60_000L * timeframe.daysCount
        val completionPercent = if (expectedGoalTotalMillis > 0L) {
            min(100, ((totalMillis * 100L) / expectedGoalTotalMillis).toInt())
        } else 0

        // Weekly Bar Chart (last 7 days)
        val last7Keys = DateTimeUtils.getLastNDaysKeys(7, todayKey)
        val byDateMap = allSessions.groupBy { it.dateKey }
            .mapValues { (_, list) -> list.sumOf { it.durationMillis } }

        val weeklyPoints = last7Keys.map { key ->
            val mins = ((byDateMap[key] ?: 0L) / 60_000f)
            DailyChartPoint(
                dateKey = key,
                shortLabel = DateTimeUtils.formatWeekdayShort(key).take(3),
                totalMinutes = mins
            )
        }

        // Monthly Performance Chart (last 30 days)
        val last30Keys = DateTimeUtils.getLastNDaysKeys(30, todayKey)
        val monthlyPoints = last30Keys.mapIndexed { index, key ->
            val mins = ((byDateMap[key] ?: 0L) / 60_000f)
            val label = if (index % 7 == 0 || index == last30Keys.lastIndex) {
                DateTimeUtils.formatMonthDay(key)
            } else ""
            DailyChartPoint(
                dateKey = key,
                shortLabel = label,
                totalMinutes = mins
            )
        }

        val durationByActivity = scopedSessions.groupBy { it.activityId }
            .mapValues { (_, list) -> list.sumOf { it.durationMillis } }
        val countByActivity = scopedSessions.groupBy { it.activityId }
            .mapValues { (_, list) -> list.size }

        val comparisons = activities.map { activity ->
            val actMs = durationByActivity[activity.id] ?: 0L
            val targetMs = activity.dailyTargetMinutes * 60_000L * timeframe.daysCount
            val share = if (totalMillis > 0L) actMs.toFloat() / totalMillis.toFloat() else 0f
            val adherence = if (targetMs > 0L) min(100, ((actMs * 100L) / targetMs).toInt()) else 0
            ActivityStatComparison(
                activity = activity,
                totalMillis = actMs,
                shareFraction = share,
                goalAdherencePercent = adherence,
                sessionsCount = countByActivity[activity.id] ?: 0
            )
        }.sortedByDescending { it.totalMillis }

        StatisticsUiState(
            timeframe = timeframe,
            totalMillis = totalMillis,
            averageDailyMillis = averageMillis,
            goalCompletionPercent = completionPercent,
            activeDaysCount = activeDays,
            totalSessionsCount = scopedSessions.size,
            weeklyBarPoints = weeklyPoints,
            monthlyTrendPoints = monthlyPoints,
            dailyGoalMinutes = prefs.overallDailyGoalMinutes,
            activityComparisons = comparisons
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), StatisticsUiState())

    val settingsState: StateFlow<SettingsUiState> = combine(
        repository.preferences,
        repository.reminders,
        repository.activities,
        repository.allSessions
    ) { prefs, reminders, activities, sessions ->
        SettingsUiState(
            preferences = prefs,
            reminders = reminders,
            activities = activities,
            totalSessionsCount = sessions.size
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), SettingsUiState())

    fun observeActivity(activityId: Long) = repository.observeActivityById(activityId)

    fun observeSessionsForActivity(activityId: Long) = repository.observeSessionsForActivity(activityId)

    fun updateSearchQuery(query: String) {
        searchQuery.value = query
    }

    fun updateActivityFilterMode(mode: ActivityFilterMode) {
        activityFilterMode.value = mode
    }

    fun selectCalendarDate(dateKey: String) {
        selectedDateKey.value = dateKey
        val cal = DateTimeUtils.parseDateKey(dateKey)
        calendarYearMonth.value = cal.get(java.util.Calendar.YEAR) to cal.get(java.util.Calendar.MONTH)
    }

    fun shiftCalendarMonth(deltaMonths: Int) {
        val (y, m) = calendarYearMonth.value
        calendarYearMonth.value = DateTimeUtils.shiftMonth(y, m, deltaMonths)
    }

    fun jumpCalendarToToday() {
        val today = DateTimeUtils.toDateKey()
        selectedDateKey.value = today
        calendarYearMonth.value = DateTimeUtils.currentYearMonth()
    }

    fun updateCalendarViewMode(mode: CalendarViewMode) {
        calendarViewMode.value = mode
    }

    fun updateStatsTimeframe(timeframe: StatsTimeframe) {
        statsTimeframe.value = timeframe
    }

    fun startActivityTimer(activity: ActivityEntity, onStarted: (() -> Unit)? = null) {
        viewModelScope.launch {
            when (val result = timerManager.startActivity(activity)) {
                is StartTimerResult.Started -> {
                    onStarted?.invoke()
                }
                is StartTimerResult.Conflict -> {
                    _timerConflict.value = result
                }
            }
        }
    }

    fun dismissTimerConflict() {
        _timerConflict.value = null
    }

    fun resolveConflictFinishAndStart(onStarted: (() -> Unit)? = null) {
        val conflict = _timerConflict.value ?: return
        viewModelScope.launch {
            timerManager.finishCurrentAndStart(conflict.requestedActivity)
            _timerConflict.value = null
            _uiMessages.tryEmit("Saved ${conflict.activeTimer.activityName} and started ${conflict.requestedActivity.name}")
            onStarted?.invoke()
        }
    }

    fun resolveConflictDiscardAndStart(onStarted: (() -> Unit)? = null) {
        val conflict = _timerConflict.value ?: return
        viewModelScope.launch {
            timerManager.discardCurrentAndStart(conflict.requestedActivity)
            _timerConflict.value = null
            _uiMessages.tryEmit("Started ${conflict.requestedActivity.name}")
            onStarted?.invoke()
        }
    }

    fun pauseTimer() {
        viewModelScope.launch { timerManager.pause() }
    }

    fun resumeTimer() {
        viewModelScope.launch { timerManager.resume() }
    }

    fun stopAndFinishTimer(notes: String = "") {
        viewModelScope.launch {
            val saved = timerManager.stopAndFinish(notes)
            if (saved != null) {
                val durText = DateTimeUtils.formatCompactDuration(saved.durationMillis)
                _uiMessages.tryEmit("Session saved ($durText)")
            }
        }
    }

    fun discardActiveTimer() {
        viewModelScope.launch {
            timerManager.discardActiveTimer()
            _uiMessages.tryEmit("Timer discarded")
        }
    }

    fun saveActivity(
        id: Long? = null,
        name: String,
        iconKey: String,
        colorHex: Long,
        dailyTargetMinutes: Int,
        description: String
    ) {
        viewModelScope.launch {
            runCatching {
                repository.saveActivity(
                    id = id,
                    name = name,
                    iconKey = iconKey,
                    colorHex = colorHex,
                    dailyTargetMinutes = dailyTargetMinutes,
                    description = description
                )
            }.onSuccess {
                _uiMessages.tryEmit(if (id == null) "Activity \"$name\" created" else "Activity \"$name\" updated")
            }.onFailure {
                _uiMessages.tryEmit(it.message ?: "Could not save activity")
            }
        }
    }

    fun deleteActivity(activity: ActivityEntity) {
        viewModelScope.launch {
            val active = timerManager.activeTimerState.value
            if (active?.activityId == activity.id) {
                timerManager.discardActiveTimer()
            }
            repository.deleteActivity(activity.id)
            _uiMessages.tryEmit("Deleted ${activity.name}")
        }
    }

    fun deleteSession(sessionId: Long) {
        viewModelScope.launch {
            repository.deleteSession(sessionId)
            _uiMessages.tryEmit("Session deleted")
        }
    }

    fun updateProfile(name: String, ageGroup: AgeGroup) {
        viewModelScope.launch {
            repository.updateProfile(name, ageGroup)
            _uiMessages.tryEmit("Profile updated")
        }
    }

    fun updateDailyGoalMinutes(minutes: Int) {
        viewModelScope.launch {
            repository.updateDailyGoalMinutes(minutes)
        }
    }

    fun updateThemeMode(mode: ThemeMode) {
        viewModelScope.launch {
            repository.updateThemeMode(mode)
        }
    }

    fun updateNotificationsEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.updateNotificationsEnabled(enabled)
            val reminders = repository.getAllRemindersOnce()
            reminderScheduler.rescheduleAll(reminders, enabled)
        }
    }

    fun updateReducedMotion(enabled: Boolean) {
        viewModelScope.launch {
            repository.updateReducedMotion(enabled)
        }
    }

    fun saveReminder(
        id: Long = 0L,
        activityId: Long?,
        title: String,
        hour: Int,
        minute: Int,
        daysMask: Int,
        isEnabled: Boolean = true
    ) {
        viewModelScope.launch {
            val entity = ReminderEntity(
                id = id,
                activityId = activityId,
                title = title.trim().ifEmpty { "Daily Practice Reminder" },
                hour = hour,
                minute = minute,
                daysOfWeekMask = if (daysMask == 0) 127 else daysMask,
                isEnabled = isEnabled
            )
            val savedId = repository.saveReminder(entity)
            val saved = entity.copy(id = savedId)
            val prefs = preferencesState.value
            if (prefs.notificationsEnabled && saved.isEnabled) {
                reminderScheduler.scheduleReminder(saved)
            } else {
                reminderScheduler.cancelReminder(saved.id)
            }
            _uiMessages.tryEmit("Reminder saved for ${DateTimeUtils.formatTimeOfDay(hour, minute)}")
        }
    }

    fun toggleReminder(reminder: ReminderEntity, enabled: Boolean) {
        viewModelScope.launch {
            val updated = reminder.copy(isEnabled = enabled)
            repository.saveReminder(updated)
            val prefs = preferencesState.value
            if (prefs.notificationsEnabled && enabled) {
                reminderScheduler.scheduleReminder(updated)
            } else {
                reminderScheduler.cancelReminder(updated.id)
            }
        }
    }

    fun deleteReminder(reminderId: Long) {
        viewModelScope.launch {
            reminderScheduler.cancelReminder(reminderId)
            repository.deleteReminder(reminderId)
            _uiMessages.tryEmit("Reminder deleted")
        }
    }

    fun exportBackupToUri(context: Context, uri: Uri) {
        viewModelScope.launch {
            runCatching {
                val jsonString = repository.exportBackupJson()
                withContext(Dispatchers.IO) {
                    context.contentResolver.openOutputStream(uri)?.use { stream ->
                        stream.write(jsonString.toByteArray(Charsets.UTF_8))
                    } ?: error("Could not open output file")
                }
            }.onSuccess {
                _uiMessages.tryEmit("Backup exported successfully")
            }.onFailure {
                _uiMessages.tryEmit("Backup failed: ${it.message}")
            }
        }
    }

    fun importBackupFromUri(context: Context, uri: Uri) {
        viewModelScope.launch {
            runCatching {
                val raw = withContext(Dispatchers.IO) {
                    context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                        ?: error("Could not read backup file")
                }
                timerManager.stopForegroundService()
                repository.importBackupJson(raw).getOrThrow()
            }.onSuccess { restoredSessions ->
                val prefs = repository.preferences
                val reminders = repository.getAllRemindersOnce()
                reminderScheduler.rescheduleAll(reminders, preferencesState.value.notificationsEnabled)
                _uiMessages.tryEmit("Restored backup ($restoredSessions sessions)")
            }.onFailure {
                _uiMessages.tryEmit("Restore failed: Invalid backup file")
            }
        }
    }

    fun exportCsvToUri(context: Context, uri: Uri) {
        viewModelScope.launch {
            runCatching {
                val csv = repository.exportSessionsCsv()
                withContext(Dispatchers.IO) {
                    context.contentResolver.openOutputStream(uri)?.use { stream ->
                        stream.write(csv.toByteArray(Charsets.UTF_8))
                    } ?: error("Could not open CSV file")
                }
            }.onSuccess {
                _uiMessages.tryEmit("Activity history CSV exported")
            }.onFailure {
                _uiMessages.tryEmit("Export failed: ${it.message}")
            }
        }
    }

    suspend fun buildShareSummaryText(): String = repository.buildPlainTextSummary(days = 7)

    fun resetSessionsOnly() {
        viewModelScope.launch {
            timerManager.stopForegroundService()
            repository.resetSessionsOnly()
            _uiMessages.tryEmit("All activity history cleared")
        }
    }

    fun resetAllApplicationData() {
        viewModelScope.launch {
            val reminders = repository.getAllRemindersOnce()
            reminders.forEach { reminderScheduler.cancelReminder(it.id) }
            timerManager.stopForegroundService()
            repository.resetAllData()
            _uiMessages.tryEmit("Application reset to factory defaults")
        }
    }
}
