package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.data.local.ActivityEntity
import com.example.service.ActivityTimerService
import com.example.ui.components.TimerConflictDialog
import com.example.ui.screens.ActivitiesScreen
import com.example.ui.screens.ActivityTimerScreen
import com.example.ui.screens.CalendarScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.StatisticsScreen
import com.example.ui.theme.LifeTrackTheme
import com.example.viewmodel.LifeTrackViewModel
import kotlinx.serialization.Serializable

@Serializable data object HomeRoute
@Serializable data object ActivitiesRoute
@Serializable data object CalendarRoute
@Serializable data object StatisticsRoute
@Serializable data object SettingsRoute
@Serializable data class ActivityTimerRoute(val activityId: Long)

private data class BottomNavItem<T : Any>(
    val route: T,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

class MainActivity : ComponentActivity() {

    private val viewModel: LifeTrackViewModel by viewModels()
    private val pendingDeepLinkActivityId = mutableStateOf<Long?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handleDeepLinkIntent(intent)

        setContent {
            val preferences by viewModel.preferencesState.collectAsStateWithLifecycle()
            LifeTrackTheme(
                themeMode = preferences.themeMode,
                reducedMotionPref = preferences.reducedMotion
            ) {
                LifeTrackAppShell(
                    viewModel = viewModel,
                    pendingDeepLinkActivityId = pendingDeepLinkActivityId.value,
                    onConsumeDeepLink = { pendingDeepLinkActivityId.value = null }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleDeepLinkIntent(intent)
    }

    private fun handleDeepLinkIntent(intent: Intent?) {
        val activityId = intent?.getLongExtra(ActivityTimerService.EXTRA_ACTIVITY_ID, -1L) ?: -1L
        if (activityId > 0L) {
            pendingDeepLinkActivityId.value = activityId
        }
    }
}

@Composable
private fun LifeTrackAppShell(
    viewModel: LifeTrackViewModel,
    pendingDeepLinkActivityId: Long?,
    onConsumeDeepLink: () -> Unit
) {
    val context = LocalContext.current
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }
    var askedNotificationPermissionOnce by remember { mutableStateOf(false) }

    val notificationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    val startActivityWithNotificationCheck: (ActivityEntity, (() -> Unit)?) -> Unit =
        { activity, onStarted ->
            if (!askedNotificationPermissionOnce && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val granted = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
                if (!granted) {
                    askedNotificationPermissionOnce = true
                    notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
            viewModel.startActivityTimer(activity, onStarted)
        }

    LaunchedEffect(Unit) {
        viewModel.uiMessages.collect { message ->
            snackbarHostState.showSnackbar(message)
        }
    }

    LaunchedEffect(pendingDeepLinkActivityId) {
        if (pendingDeepLinkActivityId != null && pendingDeepLinkActivityId > 0L) {
            navController.navigate(ActivityTimerRoute(pendingDeepLinkActivityId)) {
                launchSingleTop = true
            }
            onConsumeDeepLink()
        }
    }

    val navItems = remember {
        listOf(
            BottomNavItem(HomeRoute, "Home", Icons.Rounded.Home, Icons.Outlined.Home, "nav_home"),
            BottomNavItem(ActivitiesRoute, "Activities", Icons.Rounded.GridView, Icons.Outlined.GridView, "nav_activities"),
            BottomNavItem(CalendarRoute, "Calendar", Icons.Rounded.CalendarMonth, Icons.Outlined.CalendarMonth, "nav_calendar"),
            BottomNavItem(StatisticsRoute, "Statistics", Icons.Rounded.BarChart, Icons.Outlined.BarChart, "nav_statistics"),
            BottomNavItem(SettingsRoute, "Settings", Icons.Rounded.Settings, Icons.Outlined.Settings, "nav_settings")
        )
    }

    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = backStackEntry?.destination
    val isTopLevelDestination = currentDestination?.let { dest ->
        dest.hasRoute<HomeRoute>() ||
            dest.hasRoute<ActivitiesRoute>() ||
            dest.hasRoute<CalendarRoute>() ||
            dest.hasRoute<StatisticsRoute>() ||
            dest.hasRoute<SettingsRoute>()
    } ?: true

    val conflict by viewModel.timerConflict.collectAsStateWithLifecycle()

    val navigateTopLevel: (Any) -> Unit = { route ->
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavRail = maxWidth >= 680.dp

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            bottomBar = {
                if (isTopLevelDestination && !useNavRail) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        tonalElevation = 3.dp
                    ) {
                        navItems.forEach { item ->
                            val selected = currentDestination?.hierarchy?.any {
                                it.hasRoute(item.route::class)
                            } == true
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateTopLevel(item.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = item.label
                                    )
                                },
                                label = { Text(item.label, maxLines = 1) },
                                modifier = Modifier.testTag(item.testTag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (isTopLevelDestination && useNavRail) {
                    NavigationRail(
                        modifier = Modifier.fillMaxHeight(),
                        containerColor = MaterialTheme.colorScheme.surface
                    ) {
                        navItems.forEach { item ->
                            val selected = currentDestination?.hierarchy?.any {
                                it.hasRoute(item.route::class)
                            } == true
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateTopLevel(item.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = item.label
                                    )
                                },
                                label = { Text(item.label) },
                                modifier = Modifier.testTag(item.testTag)
                            )
                        }
                    }
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    contentAlignment = Alignment.TopCenter
                ) {
                    NavHost(
                        navController = navController,
                        startDestination = HomeRoute,
                        enterTransition = { fadeIn() },
                        exitTransition = { fadeOut() },
                        modifier = Modifier
                            .widthIn(max = 840.dp)
                            .fillMaxSize()
                    ) {
                        composable<HomeRoute> {
                            val dashboardState by viewModel.dashboardState.collectAsStateWithLifecycle()
                            HomeScreen(
                                state = dashboardState,
                                onOpenActivityTimer = { activityId ->
                                    navController.navigate(ActivityTimerRoute(activityId))
                                },
                                onStartActivity = { activity ->
                                    startActivityWithNotificationCheck(activity) {
                                        navController.navigate(ActivityTimerRoute(activity.id))
                                    }
                                },
                                onPauseTimer = { viewModel.pauseTimer() },
                                onResumeTimer = { viewModel.resumeTimer() },
                                onFinishTimer = { viewModel.stopAndFinishTimer() },
                                onDeleteSession = { viewModel.deleteSession(it) },
                                onViewAllActivities = { navigateTopLevel(ActivitiesRoute) }
                            )
                        }

                        composable<ActivitiesRoute> {
                            val activitiesState by viewModel.activitiesState.collectAsStateWithLifecycle()
                            ActivitiesScreen(
                                state = activitiesState,
                                onSearchQueryChange = viewModel::updateSearchQuery,
                                onFilterChange = viewModel::updateActivityFilterMode,
                                onOpenTimer = { activityId ->
                                    navController.navigate(ActivityTimerRoute(activityId))
                                },
                                onStartTimer = { activity ->
                                    startActivityWithNotificationCheck(activity) {
                                        navController.navigate(ActivityTimerRoute(activity.id))
                                    }
                                },
                                onPauseTimer = { viewModel.pauseTimer() },
                                onResumeTimer = { viewModel.resumeTimer() },
                                onFinishTimer = { viewModel.stopAndFinishTimer() },
                                onSaveActivity = viewModel::saveActivity,
                                onDeleteActivity = viewModel::deleteActivity
                            )
                        }

                        composable<CalendarRoute> {
                            val calendarState by viewModel.calendarState.collectAsStateWithLifecycle()
                            CalendarScreen(
                                state = calendarState,
                                onSelectDate = viewModel::selectCalendarDate,
                                onShiftMonth = viewModel::shiftCalendarMonth,
                                onJumpToday = viewModel::jumpCalendarToToday,
                                onChangeViewMode = viewModel::updateCalendarViewMode,
                                onOpenActivityTimer = { activityId ->
                                    navController.navigate(ActivityTimerRoute(activityId))
                                },
                                onDeleteSession = viewModel::deleteSession
                            )
                        }

                        composable<StatisticsRoute> {
                            val statsState by viewModel.statisticsState.collectAsStateWithLifecycle()
                            StatisticsScreen(
                                state = statsState,
                                onTimeframeChange = viewModel::updateStatsTimeframe
                            )
                        }

                        composable<SettingsRoute> {
                            val settingsState by viewModel.settingsState.collectAsStateWithLifecycle()
                            SettingsScreen(
                                state = settingsState,
                                onUpdateProfile = viewModel::updateProfile,
                                onUpdateDailyGoalMinutes = viewModel::updateDailyGoalMinutes,
                                onUpdateThemeMode = viewModel::updateThemeMode,
                                onUpdateNotificationsEnabled = viewModel::updateNotificationsEnabled,
                                onUpdateReducedMotion = viewModel::updateReducedMotion,
                                onSaveReminder = viewModel::saveReminder,
                                onToggleReminder = viewModel::toggleReminder,
                                onDeleteReminder = viewModel::deleteReminder,
                                onExportBackup = { uri -> viewModel.exportBackupToUri(context, uri) },
                                onImportBackup = { uri -> viewModel.importBackupFromUri(context, uri) },
                                onExportCsv = { uri -> viewModel.exportCsvToUri(context, uri) },
                                onBuildShareSummary = { viewModel.buildShareSummaryText() },
                                onResetSessionsOnly = viewModel::resetSessionsOnly,
                                onResetAllData = viewModel::resetAllApplicationData
                            )
                        }

                        composable<ActivityTimerRoute> { backStack ->
                            val args = backStack.toRoute<ActivityTimerRoute>()
                            val activity by viewModel.observeActivity(args.activityId)
                                .collectAsStateWithLifecycle(initialValue = null)
                            val sessions by viewModel.observeSessionsForActivity(args.activityId)
                                .collectAsStateWithLifecycle(initialValue = emptyList())
                            val activeTimer by viewModel.activeTimerState.collectAsStateWithLifecycle()

                            ActivityTimerScreen(
                                activity = activity,
                                sessions = sessions,
                                activeTimer = activeTimer,
                                onBack = { navController.popBackStack() },
                                onStart = { act -> startActivityWithNotificationCheck(act, null) },
                                onPause = { viewModel.pauseTimer() },
                                onResume = { viewModel.resumeTimer() },
                                onStopAndFinish = { notes -> viewModel.stopAndFinishTimer(notes) },
                                onDiscardTimer = { viewModel.discardActiveTimer() },
                                onDeleteSession = { viewModel.deleteSession(it) },
                                onUpdateActivity = viewModel::saveActivity
                            )
                        }
                    }
                }
            }
        }
    }

    conflict?.let { activeConflict ->
        TimerConflictDialog(
            conflict = activeConflict,
            onFinishAndStart = {
                val targetId = activeConflict.requestedActivity.id
                viewModel.resolveConflictFinishAndStart {
                    navController.navigate(ActivityTimerRoute(targetId)) {
                        launchSingleTop = true
                    }
                }
            },
            onDiscardAndStart = {
                val targetId = activeConflict.requestedActivity.id
                viewModel.resolveConflictDiscardAndStart {
                    navController.navigate(ActivityTimerRoute(targetId)) {
                        launchSingleTop = true
                    }
                }
            },
            onDismiss = viewModel::dismissTimerConflict
        )
    }
}
