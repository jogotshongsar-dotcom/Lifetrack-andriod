package com.example

import android.app.Application
import com.example.data.local.LifeTrackDatabase
import com.example.data.local.LifeTrackRepository
import com.example.data.local.UserPreferencesRepository
import com.example.service.ActivityTimerService
import com.example.service.ReminderScheduler
import com.example.service.TimerManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class LifeTrackApplication : Application() {

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val database: LifeTrackDatabase by lazy { LifeTrackDatabase.getInstance(this) }
    val preferencesRepository: UserPreferencesRepository by lazy { UserPreferencesRepository(this) }
    val repository: LifeTrackRepository by lazy {
        LifeTrackRepository(database, preferencesRepository)
    }
    val timerManager: TimerManager by lazy { TimerManager(this, repository) }
    val reminderScheduler: ReminderScheduler by lazy { ReminderScheduler(this) }

    override fun onCreate() {
        super.onCreate()
        ActivityTimerService.ensureChannel(this)
        reminderScheduler.ensureChannel()

        appScope.launch {
            repository.ensureDefaultActivitiesSeeded()
            timerManager.restoreServiceIfNeeded()
            val prefs = preferencesRepository.getOnce()
            val reminders = repository.getAllRemindersOnce()
            reminderScheduler.rescheduleAll(reminders, prefs.notificationsEnabled)
        }
    }
}
