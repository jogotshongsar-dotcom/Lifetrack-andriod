package com.example.ui.theme

import android.animation.ValueAnimator
import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import com.example.data.local.ThemeMode

val LocalReducedMotion = compositionLocalOf { false }

private val LifeTrackLightColorScheme = lightColorScheme(
    primary = ForestTealPrimary,
    onPrimary = OnForestTeal,
    primaryContainer = MintSageContainer,
    onPrimaryContainer = OnMintSageContainer,
    secondary = WarmAmberSecondary,
    onSecondary = OnWarmAmber,
    secondaryContainer = WarmSandContainer,
    onSecondaryContainer = OnWarmSandContainer,
    tertiary = IndigoTertiary,
    onTertiary = OnIndigoTertiary,
    tertiaryContainer = IndigoMistContainer,
    onTertiaryContainer = OnIndigoMistContainer,
    background = AlabasterBackground,
    onBackground = SlateInk,
    surface = CrispSurface,
    onSurface = SlateInk,
    surfaceVariant = SoftSageSurfaceVariant,
    onSurfaceVariant = MutedPineInk,
    surfaceContainerLowest = Color.White,
    surfaceContainerLow = Color(0xFFF3F6F3),
    surfaceContainer = Color(0xFFEDF2EE),
    surfaceContainerHigh = Color(0xFFE6ECE8),
    outline = SubtleBorderLight,
    outlineVariant = Color(0xFFE3EAE7),
    error = ErrorRedLight
)

private val LifeTrackDarkColorScheme = darkColorScheme(
    primary = LuminousTealPrimary,
    onPrimary = OnLuminousTeal,
    primaryContainer = DeepTealContainer,
    onPrimaryContainer = OnDeepTealContainer,
    secondary = WarmGoldSecondary,
    onSecondary = OnWarmGold,
    secondaryContainer = DeepAmberContainer,
    onSecondaryContainer = OnDeepAmberContainer,
    tertiary = PeriwinkleTertiary,
    onTertiary = OnPeriwinkleTertiary,
    tertiaryContainer = DeepIndigoContainer,
    onTertiaryContainer = OnDeepIndigoContainer,
    background = ObsidianPineBackground,
    onBackground = MistInk,
    surface = CharcoalPineSurface,
    onSurface = MistInk,
    surfaceVariant = ElevatedPineSurfaceVariant,
    onSurfaceVariant = SoftSageInk,
    surfaceContainerLowest = Color(0xFF080E0E),
    surfaceContainerLow = Color(0xFF101A1A),
    surfaceContainer = Color(0xFF152222),
    surfaceContainerHigh = Color(0xFF1C2C2C),
    outline = SubtleBorderDark,
    outlineVariant = Color(0xFF1F2F2E),
    error = ErrorRedDark
)

val LifeTrackShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(30.dp)
)

@Composable
fun LifeTrackTheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    reducedMotionPref: Boolean = false,
    content: @Composable () -> Unit
) {
    val systemDark = isSystemInDarkTheme()
    val useDark = when (themeMode) {
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
        ThemeMode.SYSTEM -> systemDark
    }

    val colorScheme = if (useDark) LifeTrackDarkColorScheme else LifeTrackLightColorScheme
    val systemAnimatorsDisabled = !ValueAnimator.areAnimatorsEnabled()
    val reducedMotion = reducedMotionPref || systemAnimatorsDisabled

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                WindowCompat.getInsetsController(window, view).apply {
                    isAppearanceLightStatusBars = !useDark
                    isAppearanceLightNavigationBars = !useDark
                }
            }
        }
    }

    CompositionLocalProvider(LocalReducedMotion provides reducedMotion) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = LifeTrackTypography,
            shapes = LifeTrackShapes,
            content = content
        )
    }
}
