package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Forest & Warm Sand Wellness Editorial Palette

// Light Scheme Tokens
val ForestTealPrimary = Color(0xFF0F5257)
val OnForestTeal = Color(0xFFFFFFFF)
val MintSageContainer = Color(0xFFD4EFEA)
val OnMintSageContainer = Color(0xFF052E32)

val WarmAmberSecondary = Color(0xFFC26A1B)
val OnWarmAmber = Color(0xFFFFFFFF)
val WarmSandContainer = Color(0xFFFFE6CC)
val OnWarmSandContainer = Color(0xFF3A1C00)

val IndigoTertiary = Color(0xFF3E4EB8)
val OnIndigoTertiary = Color(0xFFFFFFFF)
val IndigoMistContainer = Color(0xFFE0E4FF)
val OnIndigoMistContainer = Color(0xFF0E1A5C)

val AlabasterBackground = Color(0xFFF7F9F6)
val CrispSurface = Color(0xFFFFFFFF)
val SoftSageSurfaceVariant = Color(0xFFEBF0EC)
val SlateInk = Color(0xFF121D1C)
val MutedPineInk = Color(0xFF4E5E5C)
val SubtleBorderLight = Color(0xFFD5DFDC)

// Dark Scheme Tokens
val LuminousTealPrimary = Color(0xFF5EEAD4)
val OnLuminousTeal = Color(0xFF042F2E)
val DeepTealContainer = Color(0xFF134E4A)
val OnDeepTealContainer = Color(0xFFCCFBF1)

val WarmGoldSecondary = Color(0xFFFBBF24)
val OnWarmGold = Color(0xFF3B2400)
val DeepAmberContainer = Color(0xFF543308)
val OnDeepAmberContainer = Color(0xFFFFE8B8)

val PeriwinkleTertiary = Color(0xFFA5B4FC)
val OnPeriwinkleTertiary = Color(0xFF141D54)
val DeepIndigoContainer = Color(0xFF232C6D)
val OnDeepIndigoContainer = Color(0xFFE0E7FF)

val ObsidianPineBackground = Color(0xFF0A1212)
val CharcoalPineSurface = Color(0xFF121E1E)
val ElevatedPineSurfaceVariant = Color(0xFF1C2B2B)
val MistInk = Color(0xFFECF4F3)
val SoftSageInk = Color(0xFF9EB3B0)
val SubtleBorderDark = Color(0xFF283A39)

val ErrorRedLight = Color(0xFFBA1A1A)
val ErrorRedDark = Color(0xFFFFB4AB)
val SuccessGreen = Color(0xFF059669)
