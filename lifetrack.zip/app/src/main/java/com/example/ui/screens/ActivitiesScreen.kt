package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.ActivityEntity
import com.example.ui.components.ActivityEditorSheet
import com.example.ui.components.ActivityIconBadge
import com.example.ui.components.LiveTimerBanner
import com.example.util.ActivityIconCatalog
import com.example.util.DateTimeUtils
import com.example.viewmodel.ActivitiesUiState
import com.example.viewmodel.ActivityFilterMode
import com.example.viewmodel.ActivityWithProgress

@Composable
fun ActivitiesScreen(
    state: ActivitiesUiState,
    onSearchQueryChange: (String) -> Unit,
    onFilterChange: (ActivityFilterMode) -> Unit,
    onOpenTimer: (Long) -> Unit,
    onStartTimer: (ActivityEntity) -> Unit,
    onPauseTimer: () -> Unit,
    onResumeTimer: () -> Unit,
    onFinishTimer: () -> Unit,
    onSaveActivity: (
        id: Long?,
        name: String,
        iconKey: String,
        colorHex: Long,
        dailyTargetMinutes: Int,
        description: String
    ) -> Unit,
    onDeleteActivity: (ActivityEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    var editorVisible by remember { mutableStateOf(false) }
    var editingActivity by remember { mutableStateOf<ActivityEntity?>(null) }
    var deleteCandidate by remember { mutableStateOf<ActivityEntity?>(null) }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("activities_screen"),
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    editingActivity = null
                    editorVisible = true
                },
                icon = { Icon(Icons.Rounded.Add, contentDescription = null) },
                text = { Text("New Activity") },
                modifier = Modifier.testTag("add_activity_fab")
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(
                start = 16.dp,
                end = 16.dp,
                top = 12.dp,
                bottom = 96.dp
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "Activities & Practice",
                        style = MaterialTheme.typography.headlineLarge
                    )
                    Text(
                        text = "Tap any activity to open its precision timer, or add unlimited custom routines.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (state.activeTimer != null) {
                item {
                    LiveTimerBanner(
                        activeTimer = state.activeTimer,
                        onOpenTimer = onOpenTimer,
                        onPause = onPauseTimer,
                        onResume = onResumeTimer,
                        onStopAndFinish = onFinishTimer
                    )
                }
            }

            item {
                OutlinedTextField(
                    value = state.searchQuery,
                    onValueChange = onSearchQueryChange,
                    placeholder = { Text("Search activities...") },
                    leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                    trailingIcon = {
                        if (state.searchQuery.isNotEmpty()) {
                            IconButton(onClick = { onSearchQueryChange("") }) {
                                Icon(Icons.Rounded.Close, contentDescription = "Clear search")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("activities_search_input")
                )
            }

            item {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    ActivityFilterMode.entries.forEach { mode ->
                        FilterChip(
                            selected = state.filterMode == mode,
                            onClick = { onFilterChange(mode) },
                            label = { Text(mode.label) }
                        )
                    }
                }
            }

            if (state.items.isEmpty()) {
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(22.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Timer,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(40.dp)
                            )
                            Text(
                                text = "No matching activities",
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                text = "Create a custom activity for any habit, hobby, or routine.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Button(
                                onClick = {
                                    editingActivity = null
                                    editorVisible = true
                                },
                                modifier = Modifier.height(48.dp)
                            ) {
                                Text("Add Custom Activity")
                            }
                        }
                    }
                }
            } else {
                items(state.items, key = { it.activity.id }) { item ->
                    ActivityListCard(
                        item = item,
                        onOpenTimer = { onOpenTimer(item.activity.id) },
                        onStartTimer = { onStartTimer(item.activity) },
                        onEdit = {
                            editingActivity = item.activity
                            editorVisible = true
                        },
                        onDelete = { deleteCandidate = item.activity }
                    )
                }
            }
        }
    }

    if (editorVisible) {
        ActivityEditorSheet(
            existingActivity = editingActivity,
            onDismiss = { editorVisible = false },
            onSave = { id, name, iconKey, colorHex, targetMin, desc ->
                onSaveActivity(id, name, iconKey, colorHex, targetMin, desc)
                editorVisible = false
            }
        )
    }

    deleteCandidate?.let { activity ->
        AlertDialog(
            onDismissRequest = { deleteCandidate = null },
            title = { Text("Delete \"${activity.name}\"?") },
            text = {
                Text(
                    "Deleting this activity will also remove its recorded sessions. This action cannot be undone."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteActivity(activity)
                        deleteCandidate = null
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error
                    )
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { deleteCandidate = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun ActivityListCard(
    item: ActivityWithProgress,
    onOpenTimer: () -> Unit,
    onStartTimer: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val accent = ActivityIconCatalog.colorFromHex(item.activity.colorHex)
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .clickable { onOpenTimer() }
            .testTag("activity_card_${item.activity.id}"),
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(
            width = if (item.isCurrentlyActive) 2.dp else 1.dp,
            color = if (item.isCurrentlyActive) accent else MaterialTheme.colorScheme.outlineVariant
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ActivityIconBadge(
                    iconKey = item.activity.iconKey,
                    colorHex = item.activity.colorHex,
                    size = 48.dp,
                    iconSize = 24.dp
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = item.activity.name,
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (item.isGoalCompleted) {
                            Icon(
                                imageVector = Icons.Rounded.CheckCircle,
                                contentDescription = "Daily goal met",
                                tint = accent,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    if (item.activity.description.isNotBlank()) {
                        Text(
                            text = item.activity.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Text(
                        text = "Today: ${DateTimeUtils.formatCompactDuration(item.loggedMillisToday)} / Goal: ${DateTimeUtils.formatMinutesReadable(item.activity.dailyTargetMinutes)}",
                        style = MaterialTheme.typography.labelMedium,
                        color = accent,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                IconButton(
                    onClick = onEdit,
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Edit,
                        contentDescription = "Edit ${item.activity.name}",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.DeleteOutline,
                        contentDescription = "Delete ${item.activity.name}",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            LinearProgressIndicator(
                progress = { item.progressFraction },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(7.dp)
                    .clip(CircleShape),
                color = accent,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${item.sessionsCountToday} session(s) today",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Button(
                    onClick = {
                        if (item.isCurrentlyActive) onOpenTimer() else onStartTimer()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = accent),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .height(48.dp)
                        .testTag("start_activity_button_${item.activity.id}")
                ) {
                    Icon(
                        imageVector = if (item.isCurrentlyActive) Icons.Rounded.Timer else Icons.Rounded.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (item.isCurrentlyActive) "Open Timer" else "Start Activity")
                }
            }
        }
    }
}
