package com.example.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.local.ActivityEntity
import com.example.data.local.ActivitySessionEntity
import com.example.service.ActiveTimerSnapshot
import com.example.ui.components.ActivityEditorSheet
import com.example.ui.components.ActivityIconBadge
import com.example.ui.components.CircularGoalRing
import com.example.ui.components.SessionHistoryRow
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalReducedMotion
import com.example.util.ActivityIconCatalog
import com.example.util.DateTimeUtils
import com.example.viewmodel.SessionDisplayItem

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ActivityTimerScreen(
    activity: ActivityEntity?,
    sessions: List<ActivitySessionEntity>,
    activeTimer: ActiveTimerSnapshot?,
    onBack: () -> Unit,
    onStart: (ActivityEntity) -> Unit,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onStopAndFinish: (String) -> Unit,
    onDiscardTimer: () -> Unit,
    onDeleteSession: (Long) -> Unit,
    onUpdateActivity: (
        id: Long?,
        name: String,
        iconKey: String,
        colorHex: Long,
        dailyTargetMinutes: Int,
        description: String
    ) -> Unit,
    modifier: Modifier = Modifier
) {
    var sessionNote by remember { mutableStateOf("") }
    var showEditor by remember { mutableStateOf(false) }

    if (activity == null) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Activity Timer") },
                    navigationIcon = {
                        IconButton(onClick = onBack, modifier = Modifier.size(48.dp)) {
                            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                        }
                    }
                )
            }
        ) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Text("Activity not found", style = MaterialTheme.typography.titleMedium)
            }
        }
        return
    }

    val accent = ActivityIconCatalog.colorFromHex(activity.colorHex)
    val isThisActivityActive = activeTimer?.activityId == activity.id
    val isRunning = isThisActivityActive && activeTimer?.isRunning == true
    val isPaused = isThisActivityActive && activeTimer?.isRunning == false
    val liveElapsedMillis = if (isThisActivityActive) activeTimer?.currentElapsedMillis ?: 0L else 0L

    val todayKey = DateTimeUtils.toDateKey()
    val loggedTodayCompletedMillis = sessions
        .filter { it.dateKey == todayKey }
        .sumOf { it.durationMillis }
    val todayTotalWithLive = loggedTodayCompletedMillis + liveElapsedMillis
    val targetMillis = activity.dailyTargetMinutes * 60_000L
    val progress = if (targetMillis > 0L) {
        (todayTotalWithLive.toFloat() / targetMillis.toFloat()).coerceIn(0f, 1f)
    } else 0f

    val reducedMotion = LocalReducedMotion.current
    val ringScale by animateFloatAsState(
        targetValue = if (isRunning && !reducedMotion) 1.03f else 1f,
        animationSpec = spring(stiffness = 220f, dampingRatio = 0.7f),
        label = "timer_ring_scale"
    )

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("activity_timer_screen"),
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        ActivityIconBadge(
                            iconKey = activity.iconKey,
                            colorHex = activity.colorHex,
                            size = 36.dp,
                            iconSize = 18.dp
                        )
                        Text(activity.name, maxLines = 1)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.size(48.dp)) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showEditor = true },
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(Icons.Rounded.Edit, contentDescription = "Edit activity")
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (activity.description.isNotBlank()) {
                item {
                    Text(
                        text = activity.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Main Precision Timer Card
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(28.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    tonalElevation = 2.dp
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(18.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = when {
                                isRunning -> accent.copy(alpha = 0.16f)
                                isPaused -> MaterialTheme.colorScheme.secondaryContainer
                                else -> MaterialTheme.colorScheme.surfaceVariant
                            }
                        ) {
                            Text(
                                text = when {
                                    isRunning -> "ACTIVE SESSION"
                                    isPaused -> "SESSION PAUSED"
                                    else -> "READY TO PRACTICE"
                                },
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = when {
                                    isRunning -> accent
                                    isPaused -> MaterialTheme.colorScheme.onSecondaryContainer
                                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                                },
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }

                        CircularGoalRing(
                            progress = progress,
                            size = 224.dp,
                            strokeWidth = 16.dp,
                            primaryColor = accent,
                            secondaryColor = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.scale(ringScale)
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = DateTimeUtils.formatHms(liveElapsedMillis),
                                    style = MaterialTheme.typography.displayMedium.copy(
                                        fontFamily = JetBrainsMonoFontFamily,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.testTag("timer_hms_display")
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (isThisActivityActive && activeTimer != null) {
                                        "Started ${DateTimeUtils.formatTime(activeTimer.originalStartTimeMillis)}"
                                    } else {
                                        "Today: ${DateTimeUtils.formatCompactDuration(todayTotalWithLive)}"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }

                        // Today progress vs Daily Target pills
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "TODAY TOTAL",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = DateTimeUtils.formatCompactDuration(todayTotalWithLive),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "DAILY TARGET",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = DateTimeUtils.formatMinutesReadable(activity.dailyTargetMinutes),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "SESSIONS",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "${sessions.count { it.dateKey == todayKey }}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        if (isThisActivityActive) {
                            OutlinedTextField(
                                value = sessionNote,
                                onValueChange = { sessionNote = it },
                                label = { Text("Session Note (Optional)") },
                                placeholder = { Text("How did this session feel?") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        // Primary Timer Action Buttons
                        if (!isThisActivityActive) {
                            Button(
                                onClick = { onStart(activity) },
                                colors = ButtonDefaults.buttonColors(containerColor = accent),
                                shape = RoundedCornerShape(18.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(56.dp)
                                    .testTag("timer_start_button")
                            ) {
                                Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Start Activity",
                                    style = MaterialTheme.typography.titleMedium
                                )
                            }
                        } else {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                FilledTonalButton(
                                    onClick = { if (isRunning) onPause() else onResume() },
                                    shape = RoundedCornerShape(18.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(54.dp)
                                        .testTag("timer_pause_resume_button")
                                ) {
                                    Icon(
                                        imageVector = if (isRunning) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                        contentDescription = null
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(if (isRunning) "Pause" else "Resume")
                                }

                                Button(
                                    onClick = {
                                        onStopAndFinish(sessionNote)
                                        sessionNote = ""
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = MaterialTheme.colorScheme.secondary
                                    ),
                                    shape = RoundedCornerShape(18.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(54.dp)
                                        .testTag("timer_finish_button")
                                ) {
                                    Icon(Icons.Rounded.Stop, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Stop & Finish")
                                }
                            }

                            TextButton(
                                onClick = {
                                    onDiscardTimer()
                                    sessionNote = ""
                                },
                                modifier = Modifier.height(48.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.DeleteOutline,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Discard Active Session",
                                    color = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            }

            // Activity History Header
            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.History,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Activity History (${sessions.size})",
                        style = MaterialTheme.typography.titleLarge
                    )
                }
            }

            if (sessions.isEmpty()) {
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    ) {
                        Text(
                            text = "No saved sessions for ${activity.name} yet. Tap Start Activity to record your first session.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(18.dp)
                        )
                    }
                }
            } else {
                items(sessions, key = { it.id }) { session ->
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = DateTimeUtils.formatShortDate(session.dateKey),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(start = 4.dp)
                        )
                        SessionHistoryRow(
                            item = SessionDisplayItem(
                                session = session,
                                activityName = activity.name,
                                activityColorHex = activity.colorHex,
                                activityIconKey = activity.iconKey
                            ),
                            onDelete = { onDeleteSession(session.id) }
                        )
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(24.dp)) }
        }
    }

    if (showEditor) {
        ActivityEditorSheet(
            existingActivity = activity,
            onDismiss = { showEditor = false },
            onSave = { id, name, iconKey, colorHex, targetMin, desc ->
                onUpdateActivity(id, name, iconKey, colorHex, targetMin, desc)
                showEditor = false
            }
        )
    }
}
