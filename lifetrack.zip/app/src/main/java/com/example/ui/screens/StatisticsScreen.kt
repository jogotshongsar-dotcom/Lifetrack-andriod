package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.ui.components.ActivityIconBadge
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.util.ActivityIconCatalog
import com.example.util.DateTimeUtils
import com.example.viewmodel.ActivityStatComparison
import com.example.viewmodel.DailyChartPoint
import com.example.viewmodel.StatisticsUiState
import com.example.viewmodel.StatsTimeframe
import kotlin.math.max
import kotlin.math.roundToInt

@Composable
fun StatisticsScreen(
    state: StatisticsUiState,
    onTimeframeChange: (StatsTimeframe) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("statistics_screen"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "Statistics & Analytics",
                    style = MaterialTheme.typography.headlineLarge
                )
                Text(
                    text = "Monitor personal consistency, daily averages, and activity balance.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Timeframe Switcher
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatsTimeframe.entries.forEach { tf ->
                    FilterChip(
                        selected = state.timeframe == tf,
                        onClick = { onTimeframeChange(tf) },
                        label = { Text(tf.label) }
                    )
                }
            }
        }

        // KPI Summary Grid
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatKpiCard(
                        label = "TOTAL TIME",
                        value = DateTimeUtils.formatCompactDuration(state.totalMillis),
                        subtext = "${state.totalSessionsCount} sessions",
                        modifier = Modifier.weight(1f)
                    )
                    StatKpiCard(
                        label = "AVG DAILY",
                        value = DateTimeUtils.formatCompactDuration(state.averageDailyMillis),
                        subtext = "${state.activeDaysCount} active day(s)",
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatKpiCard(
                        label = "GOAL COMPLETION",
                        value = "${state.goalCompletionPercent}%",
                        subtext = "vs ${DateTimeUtils.formatMinutesReadable(state.dailyGoalMinutes)}/day",
                        modifier = Modifier.weight(1f)
                    )
                    StatKpiCard(
                        label = "TOP ACTIVITY",
                        value = state.activityComparisons.firstOrNull { it.totalMillis > 0L }?.activity?.name ?: "—",
                        subtext = state.activityComparisons.firstOrNull { it.totalMillis > 0L }?.let {
                            DateTimeUtils.formatCompactDuration(it.totalMillis)
                        } ?: "No sessions yet",
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Weekly Bar Chart Card
        item {
            WeeklyBarChartCard(
                points = state.weeklyBarPoints,
                dailyGoalMinutes = state.dailyGoalMinutes
            )
        }

        // Monthly Performance Trend Card
        item {
            MonthlyTrendChartCard(points = state.monthlyTrendPoints)
        }

        // Activity Comparison Section
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Activity Comparison (${state.timeframe.label})",
                    style = MaterialTheme.typography.titleLarge
                )
                ActivityDistributionBar(comparisons = state.activityComparisons)
            }
        }

        if (state.activityComparisons.all { it.totalMillis == 0L }) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Text(
                        text = "Complete at least one activity session to see detailed activity comparisons and charts.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(18.dp)
                    )
                }
            }
        } else {
            items(state.activityComparisons.filter { it.totalMillis > 0L }, key = { it.activity.id }) { item ->
                ActivityComparisonCard(item = item)
            }
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }
    }
}

@Composable
private fun StatKpiCard(
    label: String,
    value: String,
    subtext: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = value,
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontFamily = JetBrainsMonoFontFamily,
                    fontWeight = FontWeight.Bold
                ),
                color = MaterialTheme.colorScheme.primary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = subtext,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun WeeklyBarChartCard(
    points: List<DailyChartPoint>,
    dailyGoalMinutes: Int
) {
    var selectedIndex by remember(points) { mutableIntStateOf(points.lastIndex.coerceAtLeast(0)) }
    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary
    val track = MaterialTheme.colorScheme.surfaceVariant
    val outline = MaterialTheme.colorScheme.outline

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Weekly Activity Bar Chart",
                        style = MaterialTheme.typography.titleLarge
                    )
                    Text(
                        text = "Last 7 days • Tap any bar to inspect",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                points.getOrNull(selectedIndex)?.let { selected ->
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.primaryContainer
                    ) {
                        Text(
                            text = "${selected.shortLabel}: ${selected.totalMinutes.roundToInt()}m",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontFamily = JetBrainsMonoFontFamily,
                                fontWeight = FontWeight.Bold
                            ),
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            val maxMins = max(
                dailyGoalMinutes.toFloat(),
                points.maxOfOrNull { it.totalMinutes } ?: 60f
            ).coerceAtLeast(30f)

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(170.dp)
                    .pointerInput(points) {
                        detectTapGestures { offset ->
                            if (points.isNotEmpty()) {
                                val slotWidth = size.width / points.size.toFloat()
                                val tapped = (offset.x / slotWidth).toInt().coerceIn(0, points.lastIndex)
                                selectedIndex = tapped
                            }
                        }
                    }
            ) {
                if (points.isEmpty()) return@Canvas
                val chartHeight = size.height - 16.dp.toPx()
                val topPad = 8.dp.toPx()
                val slotWidth = size.width / points.size.toFloat()
                val barWidth = (slotWidth * 0.46f).coerceAtMost(34.dp.toPx())

                // Goal threshold dashed line
                val goalY = topPad + chartHeight * (1f - (dailyGoalMinutes.toFloat() / maxMins).coerceIn(0f, 1f))
                drawLine(
                    color = outline,
                    start = Offset(0f, goalY),
                    end = Offset(size.width, goalY),
                    strokeWidth = 1.5.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f))
                )

                points.forEachIndexed { index, point ->
                    val centerX = slotWidth * index + slotWidth / 2f
                    val left = centerX - barWidth / 2f
                    // Background track
                    drawRoundRect(
                        color = track.copy(alpha = 0.5f),
                        topLeft = Offset(left, topPad),
                        size = Size(barWidth, chartHeight),
                        cornerRadius = CornerRadius(10.dp.toPx(), 10.dp.toPx())
                    )
                    val fraction = (point.totalMinutes / maxMins).coerceIn(0f, 1f)
                    val barHeight = max(if (point.totalMinutes > 0f) 6.dp.toPx() else 0f, chartHeight * fraction)
                    if (barHeight > 0f) {
                        drawRoundRect(
                            color = if (index == selectedIndex) secondary else primary,
                            topLeft = Offset(left, topPad + chartHeight - barHeight),
                            size = Size(barWidth, barHeight),
                            cornerRadius = CornerRadius(10.dp.toPx(), 10.dp.toPx())
                        )
                    }
                }
            }

            Row(modifier = Modifier.fillMaxWidth()) {
                points.forEachIndexed { index, point ->
                    Text(
                        text = point.shortLabel,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = if (index == selectedIndex) FontWeight.Bold else FontWeight.Normal,
                        color = if (index == selectedIndex) primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
private fun MonthlyTrendChartCard(points: List<DailyChartPoint>) {
    val primary = MaterialTheme.colorScheme.primary
    val tertiary = MaterialTheme.colorScheme.tertiary

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Column {
                Text(
                    text = "30-Day Performance Trend",
                    style = MaterialTheme.typography.titleLarge
                )
                Text(
                    text = "Daily practice minutes over the past month",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            val maxMins = (points.maxOfOrNull { it.totalMinutes } ?: 60f).coerceAtLeast(30f)

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
            ) {
                if (points.size < 2) return@Canvas
                val stepX = size.width / (points.size - 1).toFloat()
                val usableHeight = size.height - 12.dp.toPx()
                val topOffset = 6.dp.toPx()

                val linePath = Path()
                val fillPath = Path()

                points.forEachIndexed { index, pt ->
                    val x = index * stepX
                    val y = topOffset + usableHeight * (1f - (pt.totalMinutes / maxMins).coerceIn(0f, 1f))
                    if (index == 0) {
                        linePath.moveTo(x, y)
                        fillPath.moveTo(x, size.height)
                        fillPath.lineTo(x, y)
                    } else {
                        linePath.lineTo(x, y)
                        fillPath.lineTo(x, y)
                    }
                    if (index == points.lastIndex) {
                        fillPath.lineTo(x, size.height)
                        fillPath.close()
                    }
                }

                drawPath(
                    path = fillPath,
                    brush = Brush.verticalGradient(
                        listOf(primary.copy(alpha = 0.28f), Color.Transparent)
                    )
                )
                drawPath(
                    path = linePath,
                    color = primary,
                    style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                )

                // Highlight latest day dot
                val lastY = topOffset + usableHeight * (1f - (points.last().totalMinutes / maxMins).coerceIn(0f, 1f))
                drawCircle(
                    color = tertiary,
                    radius = 5.dp.toPx(),
                    center = Offset(size.width, lastY)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                points.filter { it.shortLabel.isNotEmpty() }.forEach { pt ->
                    Text(
                        text = pt.shortLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun ActivityDistributionBar(comparisons: List<ActivityStatComparison>) {
    val active = comparisons.filter { it.totalMillis > 0L }
    if (active.isEmpty()) return

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(14.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.surfaceVariant),
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        active.forEach { item ->
            val weight = item.shareFraction.coerceAtLeast(0.02f)
            Box(
                modifier = Modifier
                    .weight(weight)
                    .fillMaxSize()
                    .background(ActivityIconCatalog.colorFromHex(item.activity.colorHex))
            )
        }
    }
}

@Composable
private fun ActivityComparisonCard(item: ActivityStatComparison) {
    val accent = ActivityIconCatalog.colorFromHex(item.activity.colorHex)
    val sharePercent = (item.shareFraction * 100f).roundToInt()

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ActivityIconBadge(
                    iconKey = item.activity.iconKey,
                    colorHex = item.activity.colorHex,
                    size = 40.dp,
                    iconSize = 20.dp
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.activity.name,
                        style = MaterialTheme.typography.titleSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${item.sessionsCount} session(s) • $sharePercent% of time",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = DateTimeUtils.formatCompactDuration(item.totalMillis),
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontFamily = JetBrainsMonoFontFamily,
                            fontWeight = FontWeight.Bold
                        ),
                        color = accent
                    )
                    Text(
                        text = "${item.goalAdherencePercent}% goal",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            LinearProgressIndicator(
                progress = { (item.goalAdherencePercent / 100f).coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(CircleShape),
                color = accent,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )
        }
    }
}
