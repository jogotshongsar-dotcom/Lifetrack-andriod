package com.example.service

import android.Manifest
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.LifeTrackApplication
import com.example.MainActivity
import com.example.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ReminderReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext as? LifeTrackApplication ?: return
        val reminderId = intent.getLongExtra(ReminderScheduler.EXTRA_REMINDER_ID, -1L)
        val title = intent.getStringExtra(ReminderScheduler.EXTRA_REMINDER_TITLE)
            ?: "Time for your daily practice"
        val activityId = intent.getLongExtra(ReminderScheduler.EXTRA_ACTIVITY_ID, -1L)

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val prefs = app.preferencesRepository.getOnce()
                val reminder = if (reminderId > 0L) app.repository.getReminderByIdOnce(reminderId) else null
                if (prefs.notificationsEnabled && (reminder == null || reminder.isEnabled)) {
                    showReminderNotification(context, reminderId, title, activityId)
                    if (reminder != null) {
                        app.reminderScheduler.scheduleReminder(reminder)
                    }
                }
            } finally {
                pendingResult.finish()
            }
        }
    }

    private fun showReminderNotification(
        context: Context,
        reminderId: Long,
        title: String,
        activityId: Long
    ) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) return
        }

        val scheduler = ReminderScheduler(context)
        scheduler.ensureChannel()

        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            if (activityId > 0L) {
                putExtra(ActivityTimerService.EXTRA_ACTIVITY_ID, activityId)
            }
        }
        val openPending = PendingIntent.getActivity(
            context,
            reminderId.toInt().coerceAtLeast(1),
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, ReminderScheduler.REMINDER_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText("Tap to open LifeTrack and start your practice session.")
            .setContentIntent(openPending)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(5000 + reminderId.toInt().coerceAtLeast(1), notification)
    }
}
