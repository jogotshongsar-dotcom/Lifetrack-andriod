package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.example.LifeTrackApplication
import com.example.MainActivity
import com.example.R
import com.example.data.local.ActiveTimerEntity
import com.example.util.DateTimeUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class ActivityTimerService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var tickerJob: Job? = null

    private val app get() = application as LifeTrackApplication

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        ensureChannel(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_TOGGLE_PAUSE -> {
                serviceScope.launch(Dispatchers.IO) {
                    app.timerManager.togglePauseResume()
                }
            }
            ACTION_FINISH -> {
                serviceScope.launch(Dispatchers.IO) {
                    app.timerManager.stopAndFinish()
                    stopSelf()
                }
                return START_NOT_STICKY
            }
            else -> {
                startForegroundLoop()
            }
        }
        return START_STICKY
    }

    private fun startForegroundLoop() {
        serviceScope.launch(Dispatchers.IO) {
            val active = app.repository.getActiveTimerOnce()
            if (active == null) {
                stopForegroundAndSelf()
                return@launch
            }
            val initialNotification = buildNotification(active)
            runCatching {
                val fgsType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                } else {
                    0
                }
                ServiceCompat.startForeground(
                    this@ActivityTimerService,
                    NOTIFICATION_ID,
                    initialNotification,
                    fgsType
                )
            }

            tickerJob?.cancel()
            tickerJob = serviceScope.launch(Dispatchers.IO) {
                val notificationManager =
                    getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                while (isActive) {
                    val current = app.repository.getActiveTimerOnce()
                    if (current == null) {
                        stopForegroundAndSelf()
                        break
                    }
                    runCatching {
                        notificationManager.notify(NOTIFICATION_ID, buildNotification(current))
                    }
                    if (!current.isRunning) {
                        delay(1500L)
                    } else {
                        delay(1000L)
                    }
                }
            }
        }
    }

    private fun stopForegroundAndSelf() {
        runCatching {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        }
        stopSelf()
    }

    private fun buildNotification(timer: ActiveTimerEntity): Notification {
        val elapsedMillis = app.timerManager.computeElapsedMillis(timer)
        val formattedTime = DateTimeUtils.formatHms(elapsedMillis)
        val statusLabel = if (timer.isRunning) "Running" else "Paused"
        val startTimeLabel = DateTimeUtils.formatTime(timer.originalStartTimeMillis)

        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_ACTIVITY_ID, timer.activityId)
        }
        val openAppPending = PendingIntent.getActivity(
            this,
            100,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val toggleIntent = Intent(this, ActivityTimerService::class.java).apply {
            action = ACTION_TOGGLE_PAUSE
        }
        val togglePending = PendingIntent.getService(
            this,
            101,
            toggleIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val finishIntent = Intent(this, ActivityTimerService::class.java).apply {
            action = ACTION_FINISH
        }
        val finishPending = PendingIntent.getService(
            this,
            102,
            finishIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("${timer.activityName} • $formattedTime")
            .setContentText("$statusLabel since $startTimeLabel")
            .setContentIntent(openAppPending)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_STOPWATCH)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .addAction(
                0,
                if (timer.isRunning) "Pause" else "Resume",
                togglePending
            )
            .addAction(
                0,
                "Finish",
                finishPending
            )
            .build()
    }

    override fun onDestroy() {
        tickerJob?.cancel()
        serviceScope.cancel()
        super.onDestroy()
    }

    companion object {
        const val CHANNEL_ID = "lifetrack_timer_channel"
        const val NOTIFICATION_ID = 4101
        const val ACTION_START_OR_SYNC = "com.example.action.TIMER_SYNC"
        const val ACTION_PAUSE_SYNC = "com.example.action.TIMER_PAUSE_SYNC"
        const val ACTION_TOGGLE_PAUSE = "com.example.action.TIMER_TOGGLE_PAUSE"
        const val ACTION_FINISH = "com.example.action.TIMER_FINISH"
        const val EXTRA_ACTIVITY_ID = "extra_activity_id"

        fun ensureChannel(context: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                val existing = manager.getNotificationChannel(CHANNEL_ID)
                if (existing == null) {
                    val channel = NotificationChannel(
                        CHANNEL_ID,
                        "Active Activity Timer",
                        NotificationManager.IMPORTANCE_LOW
                    ).apply {
                        description = "Displays your live running or paused activity timer."
                        setShowBadge(false)
                    }
                    manager.createNotificationChannel(channel)
                }
            }
        }
    }
}
