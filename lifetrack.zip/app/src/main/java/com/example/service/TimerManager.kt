package com.example.service

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.example.data.local.ActiveTimerEntity
import com.example.data.local.ActivityEntity
import com.example.data.local.ActivitySessionEntity
import com.example.data.local.LifeTrackRepository
import com.example.util.DateTimeUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.math.max

data class ActiveTimerSnapshot(
    val entity: ActiveTimerEntity,
    val currentElapsedMillis: Long
) {
    val activityId: Long get() = entity.activityId
    val activityName: String get() = entity.activityName
    val activityColorHex: Long get() = entity.activityColorHex
    val activityIconKey: String get() = entity.activityIconKey
    val originalStartTimeMillis: Long get() = entity.originalStartTimeMillis
    val isRunning: Boolean get() = entity.isRunning
}

sealed interface StartTimerResult {
    data object Started : StartTimerResult
    data class Conflict(
        val activeTimer: ActiveTimerSnapshot,
        val requestedActivity: ActivityEntity
    ) : StartTimerResult
}

class TimerManager(
    private val appContext: Context,
    private val repository: LifeTrackRepository
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mutex = Mutex()

    private val tickerFlow = flow {
        while (true) {
            emit(System.currentTimeMillis())
            delay(500L)
        }
    }

    val activeTimerState: StateFlow<ActiveTimerSnapshot?> =
        combine(repository.activeTimer, tickerFlow) { entity, nowMillis ->
            entity?.let {
                ActiveTimerSnapshot(
                    entity = it,
                    currentElapsedMillis = computeElapsedMillis(it, nowMillis)
                )
            }
        }.stateIn(
            scope = scope,
            started = SharingStarted.Eagerly,
            initialValue = null
        )

    fun computeElapsedMillis(entity: ActiveTimerEntity, nowMillis: Long = System.currentTimeMillis()): Long {
        return if (entity.isRunning) {
            entity.accumulatedDurationMillis + max(0L, nowMillis - entity.lastResumeWallTimeMillis)
        } else {
            entity.accumulatedDurationMillis
        }
    }

    suspend fun startActivity(activity: ActivityEntity): StartTimerResult = mutex.withLock {
        val current = repository.getActiveTimerOnce()
        val now = System.currentTimeMillis()
        if (current != null) {
            if (current.activityId == activity.id) {
                if (!current.isRunning) {
                    val resumed = current.copy(
                        lastResumeWallTimeMillis = now,
                        isRunning = true
                    )
                    repository.upsertActiveTimer(resumed)
                    syncForegroundService(isRunning = true)
                }
                return StartTimerResult.Started
            }
            return StartTimerResult.Conflict(
                activeTimer = ActiveTimerSnapshot(
                    entity = current,
                    currentElapsedMillis = computeElapsedMillis(current, now)
                ),
                requestedActivity = activity
            )
        }

        val fresh = ActiveTimerEntity(
            id = 1,
            activityId = activity.id,
            activityName = activity.name,
            activityColorHex = activity.colorHex,
            activityIconKey = activity.iconKey,
            originalStartTimeMillis = now,
            lastResumeWallTimeMillis = now,
            accumulatedDurationMillis = 0L,
            isRunning = true
        )
        repository.upsertActiveTimer(fresh)
        syncForegroundService(isRunning = true)
        StartTimerResult.Started
    }

    suspend fun finishCurrentAndStart(newActivity: ActivityEntity, notes: String = "") {
        stopAndFinishInternal(notes = notes)
        startActivity(newActivity)
    }

    suspend fun discardCurrentAndStart(newActivity: ActivityEntity) {
        discardActiveTimerInternal()
        startActivity(newActivity)
    }

    suspend fun pause() = mutex.withLock {
        val current = repository.getActiveTimerOnce() ?: return@withLock
        if (!current.isRunning) return@withLock
        val now = System.currentTimeMillis()
        val updatedAccumulated = current.accumulatedDurationMillis + max(0L, now - current.lastResumeWallTimeMillis)
        val paused = current.copy(
            accumulatedDurationMillis = updatedAccumulated,
            lastResumeWallTimeMillis = now,
            isRunning = false
        )
        repository.upsertActiveTimer(paused)
        syncForegroundService(isRunning = false)
    }

    suspend fun resume() = mutex.withLock {
        val current = repository.getActiveTimerOnce() ?: return@withLock
        if (current.isRunning) return@withLock
        val now = System.currentTimeMillis()
        val resumed = current.copy(
            lastResumeWallTimeMillis = now,
            isRunning = true
        )
        repository.upsertActiveTimer(resumed)
        syncForegroundService(isRunning = true)
    }

    suspend fun togglePauseResume() {
        val current = repository.getActiveTimerOnce() ?: return
        if (current.isRunning) pause() else resume()
    }

    suspend fun stopAndFinish(notes: String = ""): ActivitySessionEntity? = mutex.withLock {
        stopAndFinishInternal(notes)
    }

    private suspend fun stopAndFinishInternal(notes: String): ActivitySessionEntity? {
        val current = repository.getActiveTimerOnce() ?: return null
        val now = System.currentTimeMillis()
        val rawDuration = computeElapsedMillis(current, now)
        val finalDuration = max(1000L, rawDuration)
        val startMillis = current.originalStartTimeMillis
        val session = ActivitySessionEntity(
            activityId = current.activityId,
            startTimeMillis = startMillis,
            endTimeMillis = max(startMillis + 1000L, now),
            durationMillis = finalDuration,
            dateKey = DateTimeUtils.toDateKey(startMillis),
            notes = notes.trim()
        )
        val savedId = repository.insertSession(session)
        repository.clearActiveTimer()
        stopForegroundService()
        return session.copy(id = savedId)
    }

    suspend fun discardActiveTimer() = mutex.withLock {
        discardActiveTimerInternal()
    }

    private suspend fun discardActiveTimerInternal() {
        repository.clearActiveTimer()
        stopForegroundService()
    }

    fun restoreServiceIfNeeded() {
        scope.launch {
            val active = repository.getActiveTimerOnce()
            if (active != null && active.isRunning) {
                syncForegroundService(isRunning = true)
            }
        }
    }

    fun syncForegroundService(isRunning: Boolean) {
        runCatching {
            val intent = Intent(appContext, ActivityTimerService::class.java).apply {
                action = if (isRunning) ActivityTimerService.ACTION_START_OR_SYNC else ActivityTimerService.ACTION_PAUSE_SYNC
            }
            ContextCompat.startForegroundService(appContext, intent)
        }
    }

    fun stopForegroundService() {
        runCatching {
            val intent = Intent(appContext, ActivityTimerService::class.java)
            appContext.stopService(intent)
        }
    }
}
