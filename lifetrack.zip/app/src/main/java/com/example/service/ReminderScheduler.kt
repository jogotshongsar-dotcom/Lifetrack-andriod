package com.example.service

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.example.data.local.ReminderEntity
import com.example.util.DateTimeUtils
import java.util.Calendar

class ReminderScheduler(private val context: Context) {

    fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (manager.getNotificationChannel(REMINDER_CHANNEL_ID) == null) {
                val channel = NotificationChannel(
                    REMINDER_CHANNEL_ID,
                    "Daily Practice Reminders",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Reminders for scheduled daily activities and practice goals."
                }
                manager.createNotificationChannel(channel)
            }
        }
    }

    fun scheduleReminder(reminder: ReminderEntity) {
        ensureChannel()
        if (!reminder.isEnabled || reminder.daysOfWeekMask == 0) {
            cancelReminder(reminder.id)
            return
        }
        val triggerAtMillis = computeNextTriggerMillis(
            hour = reminder.hour,
            minute = reminder.minute,
            daysMask = reminder.daysOfWeekMask
        ) ?: return

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pendingIntent = createPendingIntent(reminder)
        runCatching {
            alarmManager.setAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                triggerAtMillis,
                pendingIntent
            )
        }
    }

    fun cancelReminder(reminderId: Long) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ReminderReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            reminderId.toInt(),
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
        }
    }

    fun rescheduleAll(reminders: List<ReminderEntity>, notificationsEnabled: Boolean) {
        reminders.forEach { reminder ->
            if (notificationsEnabled && reminder.isEnabled) {
                scheduleReminder(reminder)
            } else {
                cancelReminder(reminder.id)
            }
        }
    }

    private fun createPendingIntent(reminder: ReminderEntity): PendingIntent {
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra(EXTRA_REMINDER_ID, reminder.id)
            putExtra(EXTRA_REMINDER_TITLE, reminder.title)
            putExtra(EXTRA_ACTIVITY_ID, reminder.activityId ?: -1L)
        }
        return PendingIntent.getBroadcast(
            context,
            reminder.id.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun computeNextTriggerMillis(hour: Int, minute: Int, daysMask: Int): Long? {
        val now = Calendar.getInstance()
        for (offset in 0..7) {
            val candidate = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, offset)
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val bit = DateTimeUtils.calendarDayToMaskBit(candidate.get(Calendar.DAY_OF_WEEK))
            val isDayEnabled = (daysMask and (1 shl bit)) != 0
            if (isDayEnabled && candidate.timeInMillis > now.timeInMillis + 1500L) {
                return candidate.timeInMillis
            }
        }
        return null
    }

    companion object {
        const val REMINDER_CHANNEL_ID = "lifetrack_reminders_channel"
        const val EXTRA_REMINDER_ID = "extra_reminder_id"
        const val EXTRA_REMINDER_TITLE = "extra_reminder_title"
        const val EXTRA_ACTIVITY_ID = "extra_reminder_activity_id"
    }
}
