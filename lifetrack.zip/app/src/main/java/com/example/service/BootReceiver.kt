package com.example.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.LifeTrackApplication
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED && action != Intent.ACTION_MY_PACKAGE_REPLACED) {
            return
        }
        val app = context.applicationContext as? LifeTrackApplication ?: return
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val prefs = app.preferencesRepository.getOnce()
                val reminders = app.repository.getAllRemindersOnce()
                app.reminderScheduler.rescheduleAll(reminders, prefs.notificationsEnabled)
                app.timerManager.restoreServiceIfNeeded()
            } finally {
                pendingResult.finish()
            }
        }
    }
}
